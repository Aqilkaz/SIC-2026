import { Opportunity, ActiveCollection, Transaction, SupplierListing, BuyerProduct } from '../types';

export const INITIAL_OPPORTUNITIES: Opportunity[] = [
  {
    id: 'opp-1',
    title: 'Kain Kapas',
    fabricType: 'Kapas',
    quantityPieces: 20,
    distanceKm: 5,
    estEarnings: 35,
    deadline: '20 September 2026',
    supplierName: 'Hotel Rakan SewSmart ✓',
    supplierLocation: 'Kuala Lumpur (Jalan Raja Chulan)',
    supplierAddress: 'Hotel Rakan SewSmart, Pintu Punggah Belakang (Loading Bay 2), Jalan Raja Chulan, 50200 Kuala Lumpur',
    description: 'Cadar dan tuala hotel warna putih 100% kapas (20 helai / pcs). Sudah dicuci bersih oleh pihak hotel. Sangat sesuai untuk kraftangan, sarung kusyen dan beg jinjing.',
    photoUrl: 'https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=600&q=80',
    pickupNote: 'Bawa 2 beg atau karung. Boleh diambil antara jam 10 pagi hingga 4 petang.'
  },
  {
    id: 'opp-2',
    title: 'Denim',
    fabricType: 'Denim',
    quantityPieces: 8,
    distanceKm: 3,
    estEarnings: 18,
    deadline: '21 September 2026',
    supplierName: 'Bengkel Jahit Cheras ✓',
    supplierLocation: 'Cheras (3 km dari anda)',
    supplierAddress: 'Bengkel Jahit Cheras, No. 18 Jalan Mahkota, Maluri, 55100 Kuala Lumpur',
    description: 'Lebihan potongan kain denim seluar jeans biru pekat (8 helai / pcs). Kain tebal dan bersih, tiada minyak atau kotoran.',
    photoUrl: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=600&q=80',
    pickupNote: 'Kain telah diikat kemas dalam bungkusan tali. Mudah dibawa menaiki motorsikal.'
  },
  {
    id: 'opp-3',
    title: 'Polyester & Kain Jersi',
    fabricType: 'Polyester',
    quantityPieces: 15,
    distanceKm: 7,
    estEarnings: 25,
    deadline: '23 September 2026',
    supplierName: 'Kilang Uniform Ampang ✓',
    supplierLocation: 'Ampang (7 km dari anda)',
    supplierAddress: 'Kilang Uniform Ampang, Lot 4 Jalan Pandan Indah, 55100 Ampang',
    description: 'Potongan kain mikrofiber jersi sukan pelbagai warna (15 helai / pcs). Licin, tidak mudah kedut dan cepat kering.',
    photoUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=600&q=80',
    pickupNote: 'Ambil di pondok pengawal hadapan kilang. Sebut nombor rujukan SewSmart #AMP-15.'
  },
  {
    id: 'opp-4',
    title: 'Kain Linen & Fabrik Meja',
    fabricType: 'Lain-lain',
    quantityPieces: 12,
    distanceKm: 6,
    estEarnings: 22,
    deadline: '24 September 2026',
    supplierName: 'Kafe & Restoran Bangsar ✓',
    supplierLocation: 'Bangsar (6 km dari anda)',
    supplierAddress: 'Kafe Bangsar, No 12 Jalan Telawi 3, Bangsar Baru, 59100 Kuala Lumpur',
    description: 'Kain alas meja linen warna beige dan krim asli (12 helai / pcs). Kualiti baik, tekstur tenunan jelas.',
    photoUrl: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=600&q=80',
    pickupNote: 'Kain sudah dilipat kemas di dalam kotak kertas.'
  }
];

export const INITIAL_ACTIVE_COLLECTION: ActiveCollection = {
  id: 'col-4821',
  opportunityId: 'opp-1',
  fabricType: 'Kapas',
  quantityPieces: 20,
  condition: 'Baik',
  status: 'sudah_diambil',
  currentStep: 3, // Current step is step 3: "Asingkan kain"
  estEarnings: 35,
  photoUrl: 'https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=600&q=80',
  supplierName: 'Hotel Rakan SewSmart ✓',
  notes: 'Kain putih cadar hotel, sudah sampai di rumah dan sedia untuk diasingkan mengikut kepingan.',
  buyerName: 'EcoCraft Malaysia',
  buyerDemand: '10–20 helai (pcs) kain kapas',
  buyerPayment: 60
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    title: 'Kain Kapas',
    date: '16 September 2026',
    fabricType: 'Kapas',
    amount: 18,
    status: 'Sudah dibayar'
  },
  {
    id: 'tx-2',
    title: 'Denim',
    date: '12 September 2026',
    fabricType: 'Denim',
    amount: 32,
    status: 'Sudah dibayar'
  },
  {
    id: 'tx-3',
    title: 'Kain Kapas',
    date: '5 September 2026',
    fabricType: 'Kapas',
    amount: 20,
    status: 'Sudah dibayar'
  }
];

export const INITIAL_SUPPLIER_LISTINGS: SupplierListing[] = [
  {
    id: 'sup-1',
    fabricType: 'Kain Kapas (Cadar & Tuala)',
    quantityPieces: 20,
    condition: 'Baik & Sudah Dicuci',
    location: 'Hotel Rakan SewSmart, Jalan Raja Chulan',
    dateAvailable: '20 September 2026',
    status: 'Pengumpul ditemui',
    collectorName: 'Aina (Pengumpul B40)'
  },
  {
    id: 'sup-2',
    fabricType: 'Potongan Kain Denim Tebal',
    quantityPieces: 35,
    condition: 'Keratan Bersih',
    location: 'Bengkel Tekstil Cheras',
    dateAvailable: '22 September 2026',
    status: 'Sudah dikutip',
    collectorName: 'Salmah'
  },
  {
    id: 'sup-3',
    fabricType: 'Kain Campuran & Linen',
    quantityPieces: 15,
    condition: 'Sederhana',
    location: 'Pusat Konvensyen KL',
    dateAvailable: '25 September 2026',
    status: 'Menunggu pengumpul'
  }
];

export const INITIAL_BUYER_PRODUCTS: BuyerProduct[] = [
  {
    id: 'buy-1',
    title: 'Kain Kapas Putih Gred Baik',
    fabricType: 'Kapas',
    quantityPieces: 12,
    condition: 'Baik',
    pricePerPiece: 5,
    totalPrice: 60,
    location: 'Kuala Lumpur',
    photoUrl: 'https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=600&q=80',
    collectorName: 'Aina (Pengumpul Sah)',
    description: '100% kapas putih hotel, telah diasingkan dan dilipat kemas (12 helai / pcs). Bebas kotoran minyak, siap untuk upcycling atau kraftangan.'
  },
  {
    id: 'buy-2',
    title: 'Potongan Denim Biru Gelap',
    fabricType: 'Denim',
    quantityPieces: 8,
    condition: 'Baik',
    pricePerPiece: 4.5,
    totalPrice: 36,
    location: 'Selangor',
    photoUrl: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=600&q=80',
    collectorName: 'Kak Salmah',
    description: 'Denim tebal tulen dari lebihan kilang seluar jins (8 helai / pcs). Sangat sesuai untuk pembuatan beg tote, pouch, dan alas kaki kraf.'
  },
  {
    id: 'buy-3',
    title: 'Kain Linen Natural & Cream',
    fabricType: 'Lain-lain',
    quantityPieces: 10,
    condition: 'Baik',
    pricePerPiece: 6,
    totalPrice: 60,
    location: 'Kuala Lumpur',
    photoUrl: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=600&q=80',
    collectorName: 'Kak Aminah',
    description: 'Linen asli berkualiti tinggi dari restoran hotel (10 helai / pcs). Bersih dan sesuai untuk sulaman tangan serta sarung kusyen mewah.'
  }
];
