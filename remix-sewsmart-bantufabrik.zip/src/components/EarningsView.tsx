import React, { useState } from 'react';
import { Transaction, AppLanguage } from '../types';
import { ArrowDownLeft, CheckCircle2, X } from 'lucide-react';

interface EarningsViewProps {
  language: AppLanguage;
  transactions: Transaction[];
  onWithdrawSuccess: (amount: number) => void;
}

export const EarningsView: React.FC<EarningsViewProps> = ({
  language,
  transactions,
  onWithdrawSuccess
}) => {
  const isBm = language === 'bm';
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [selectedBank, setSelectedBank] = useState('Bank Simpanan Nasional (BSN)');
  const [accountNumber, setAccountNumber] = useState('1410-0293-8812');
  const [isSuccess, setIsSuccess] = useState(false);

  const availableBalance = 124.50;
  const thisMonth = 124.50;
  const pending = 32.00;
  const totalEarned = 386.50;

  const handleConfirmWithdraw = () => {
    setIsSuccess(true);
    setTimeout(() => {
      onWithdrawSuccess(availableBalance);
      setIsWithdrawOpen(false);
      setIsSuccess(false);
    }, 1800);
  };

  return (
    <div className="space-y-6 pb-6">
      {/* Title */}
      <div className="pt-1">
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-[#2b5b4b]">
          {isBm ? 'Pendapatan Saya' : 'My Earnings'}
        </h1>
        <p className="text-sm text-[#315f4f] mt-0.5">
          {isBm ? 'Dompet sifar modal anda di SewSmart.' : 'Your zero-capital wallet on SewSmart.'}
        </p>
      </div>

      {/* Main Wallet Card (Containers #f8f4ee) */}
      <div className="bg-[#f8f4ee] rounded-3xl p-6 sm:p-7 shadow-sm border border-[#e8dfd5] space-y-5">
        <div>
          <span className="text-xs font-bold text-[#23755c] uppercase tracking-wider block">
            {isBm ? 'Boleh dikeluarkan' : 'Available for withdrawal'}
          </span>
          <div className="font-display font-black text-4xl sm:text-5xl text-[#2b5b4b] mt-1 tracking-tight">
            RM{availableBalance.toFixed(2)}
          </div>
        </div>

        {/* Large Button: “Keluarkan Wang” (Buttons #60a103) */}
        <button
          type="button"
          onClick={() => setIsWithdrawOpen(true)}
          className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
        >
          <ArrowDownLeft className="w-5 h-5 text-white" />
          <span>{isBm ? 'Keluarkan Wang' : 'Withdraw Money'}</span>
        </button>

        {/* 3 Simple Metric Blocks */}
        <div className="grid grid-cols-3 gap-2.5 pt-3 border-t border-[#e8dfd5] text-center">
          <div className="bg-white p-3 rounded-2xl border border-[#e8dfd5]">
            <span className="text-xs text-[#315f4f]/80 font-medium block">
              {isBm ? 'Bulan Ini' : 'This Month'}
            </span>
            <span className="font-display font-black text-lg text-[#2b5b4b] mt-1 block">
              RM{thisMonth.toFixed(2)}
            </span>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-[#e8dfd5]">
            <span className="text-xs text-[#315f4f]/80 font-medium block">
              {isBm ? 'Belum Dibayar' : 'Pending'}
            </span>
            <span className="font-display font-black text-lg text-[#23755c] mt-1 block">
              RM{pending.toFixed(0)}
            </span>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-[#e8dfd5]">
            <span className="text-xs text-[#315f4f]/80 font-medium block">
              {isBm ? 'Jumlah Diperoleh' : 'Total Earned'}
            </span>
            <span className="font-display font-black text-lg text-[#2b5b4b] mt-1 block">
              RM{totalEarned.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Short Transaction List */}
      <div className="space-y-3 pt-1">
        <h2 className="font-display font-extrabold text-lg text-[#2b5b4b]">
          {isBm ? 'Riwayat Bayaran' : 'Payment History'}
        </h2>

        <div className="space-y-2.5">
          {transactions.map((tx) => (
            <div
              key={tx.id}
              className="bg-[#f8f4ee] rounded-2xl p-4 shadow-xs border border-[#e8dfd5] flex items-center justify-between"
            >
              <div className="space-y-0.5">
                <h3 className="font-bold text-base text-[#2b5b4b]">
                  {tx.title}
                </h3>
                <p className="text-xs text-[#315f4f]">
                  {tx.date} · <span className="text-[#23755c] font-bold">{isBm ? tx.status : 'Paid'}</span>
                </p>
              </div>
              <div className="text-right">
                <span className="font-display font-black text-xl text-[#2b5b4b]">
                  + RM{tx.amount.toFixed(0)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Withdrawal Dialog / Modal */}
      {isWithdrawOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] space-y-5">
            {!isSuccess ? (
              <>
                <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
                  <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                    {isBm ? 'Keluarkan Wang' : 'Withdraw Earnings'}
                  </h3>
                  <button
                    onClick={() => setIsWithdrawOpen(false)}
                    className="p-1.5 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-[#f8f4ee] touch-target"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="bg-[#f8f4ee] border border-[#23755c]/20 p-4 rounded-2xl text-center">
                  <span className="text-xs font-bold text-[#23755c] uppercase tracking-wider block">
                    {isBm ? 'Jumlah Pengeluaran' : 'Withdrawal Amount'}
                  </span>
                  <div className="font-display font-black text-3xl text-[#2b5b4b] mt-0.5">
                    RM{availableBalance.toFixed(2)}
                  </div>
                </div>

                <div className="space-y-3 text-sm">
                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Pilih Bank / E-Dompet:' : 'Select Bank / E-Wallet:'}
                    </label>
                    <select
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className="w-full p-3 rounded-xl border border-[#e8dfd5] bg-[#f8f4ee] font-semibold text-[#315f4f] focus:border-[#2b5b4b] focus:outline-none"
                    >
                      <option value="Bank Simpanan Nasional (BSN)">Bank Simpanan Nasional (BSN)</option>
                      <option value="Maybank (Malayan Banking)">Maybank</option>
                      <option value="CIMB Bank">CIMB Bank</option>
                      <option value="Touch 'n Go eWallet">Touch 'n Go eWallet (DuitNow)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Nombor Akaun Penerima:' : 'Recipient Account Number:'}
                    </label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      className="w-full p-3 rounded-xl border border-[#e8dfd5] bg-[#f8f4ee] font-semibold text-[#315f4f] focus:border-[#2b5b4b] focus:outline-none"
                    />
                    <span className="text-[11px] text-[#315f4f]/80 mt-1 block">
                      {isBm ? 'Nama akaun: Aina Binti Ramli (Disahkan)' : 'Account name: Aina Binti Ramli (Verified)'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleConfirmWithdraw}
                  className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition touch-target"
                >
                  {isBm ? 'Sahkan Pengeluaran' : 'Confirm Withdrawal'}
                </button>
              </>
            ) : (
              <div className="py-6 text-center space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 rounded-full bg-[#f8f4ee] text-[#2b5b4b] mx-auto flex items-center justify-center border border-[#23755c]/20">
                  <CheckCircle2 className="w-10 h-10 text-[#60a103]" />
                </div>
                <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                  {isBm ? 'Permohonan Berjaya!' : 'Withdrawal Successful!'}
                </h3>
                <p className="text-sm text-[#315f4f]">
                  {isBm
                    ? `RM${availableBalance.toFixed(2)} sedang dihantar ke akaun ${selectedBank}.`
                    : `RM${availableBalance.toFixed(2)} is being transferred to ${selectedBank}.`}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
