import React, { useState } from 'react';
import { FabricType, FabricCondition, AppLanguage } from '../types';
import { CheckCircle2, ArrowRight, Edit3, Sparkles } from 'lucide-react';

interface ListingPreviewModalProps {
  language: AppLanguage;
  data: {
    fabricType: FabricType;
    condition: FabricCondition;
    quantityPieces: number;
    notes?: string;
    photoUrl: string;
  };
  onEdit: () => void;
  onConfirmListing: () => void;
  onGoToEarnings: () => void;
}

export const ListingPreviewModal: React.FC<ListingPreviewModalProps> = ({
  language,
  data,
  onEdit,
  onConfirmListing,
  onGoToEarnings
}) => {
  const isBm = language === 'bm';
  const [isConfirmed, setIsConfirmed] = useState(false);

  const pricePerPiece = data.fabricType === 'Denim' ? 4.5 : data.fabricType === 'Polyester' ? 3.5 : 5.0;
  const totalEst = Math.round(data.quantityPieces * pricePerPiece);

  const handleConfirm = () => {
    setIsConfirmed(true);
    onConfirmListing();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-[#e8dfd5] my-auto">
        {!isConfirmed ? (
          <div className="p-6 sm:p-7 space-y-5">
            {/* Header */}
            <div>
              <span className="text-xs font-bold text-[#23755c] uppercase tracking-wider block">
                {isBm ? 'Pratonton Senarai' : 'Listing Preview'}
              </span>
              <h2 className="font-display font-extrabold text-2xl text-[#2b5b4b] mt-0.5">
                Kain {data.fabricType}
              </h2>
              <p className="text-sm text-[#315f4f] font-semibold mt-0.5">
                {data.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'} · {isBm ? `Keadaan ${data.condition.toLowerCase()}` : `${data.condition} condition`}
              </p>
            </div>

            {/* Estimated Pricing Badge (Containers #f8f4ee) */}
            <div className="bg-[#f8f4ee] text-[#2b5b4b] border border-[#23755c]/20 p-4 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider block text-[#23755c]">
                  {isBm ? 'Anggaran harga:' : 'Estimated price:'}
                </span>
                <span className="font-display font-extrabold text-xl text-[#2b5b4b]">
                  RM{pricePerPiece.toFixed(2)}/{isBm ? 'helai (pc)' : 'pc'}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs text-[#315f4f] font-medium block">
                  {isBm ? 'Jumlah anggaran' : 'Total estimate'}
                </span>
                <span className="font-display font-black text-2xl text-[#2b5b4b]">
                  ~RM{totalEst}
                </span>
              </div>
            </div>

            {/* Photo Preview */}
            <div className="h-44 w-full rounded-2xl overflow-hidden border border-[#e8dfd5] relative">
              <img
                src={data.photoUrl}
                alt="Fabric to list"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Confirmation Question */}
            <div className="text-center pt-1">
              <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                {isBm ? 'Semuanya betul?' : 'Is everything correct?'}
              </h3>
            </div>

            {/* Buttons: “Ya, Senaraikan” (Buttons #60a103) and “Ubah” */}
            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={handleConfirm}
                className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
              >
                <span>{isBm ? 'Ya, Senaraikan' : 'Yes, List It'}</span>
                <CheckCircle2 className="w-5 h-5 text-white" />
              </button>

              <button
                type="button"
                onClick={onEdit}
                className="w-full py-3 text-center text-sm font-bold text-[#315f4f] hover:text-[#2b5b4b] rounded-xl hover:bg-[#f8f4ee] transition flex items-center justify-center gap-1.5"
              >
                <Edit3 className="w-4 h-4" />
                <span>{isBm ? 'Ubah' : 'Edit'}</span>
              </button>
            </div>
          </div>
        ) : (
          /* Post-Confirmation Screen */
          <div className="p-7 sm:p-8 space-y-6 text-center animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-[#f8f4ee] text-[#2b5b4b] mx-auto flex items-center justify-center shadow-xs border border-[#23755c]/20">
              <Sparkles className="w-9 h-9 text-[#60a103]" />
            </div>

            <div>
              <h2 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
                {isBm ? 'Kain anda sudah disenaraikan! 🎉' : 'Your fabric is now listed! 🎉'}
              </h2>
              <p className="text-sm font-medium text-[#315f4f] mt-2 leading-relaxed">
                {isBm
                  ? 'Sekarang SewSmart akan membantu mencari pembeli.'
                  : 'Now SewSmart will help match buyers for you.'}
              </p>
            </div>

            <div className="bg-[#f8f4ee] p-4 rounded-2xl border border-[#e8dfd5] text-left text-xs space-y-1 text-[#315f4f]">
              <p className="font-bold text-[#2b5b4b] text-sm">Status:</p>
              <p>✓ Kain sedia di pasaran SewSmart</p>
              <p>✓ Notifikasi automatik kepada pembeli kraf berdekatan</p>
            </div>

            <button
              type="button"
              onClick={onGoToEarnings}
              className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
            >
              <span>{isBm ? 'Lihat Pendapatan' : 'View Earnings'}</span>
              <ArrowRight className="w-5 h-5 text-white" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
