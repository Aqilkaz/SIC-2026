import React, { useState, useEffect } from 'react';
import { AppLanguage } from '../types';
import { CheckCircle2, ArrowRight } from 'lucide-react';

interface PaymentSuccessModalProps {
  language: AppLanguage;
  amount?: number;
  onClose: () => void;
  onGoToEarnings: () => void;
}

export const PaymentSuccessModal: React.FC<PaymentSuccessModalProps> = ({
  language,
  amount = 18,
  onClose,
  onGoToEarnings
}) => {
  const isBm = language === 'bm';
  const [isCredited, setIsCredited] = useState(false);

  // Auto-progress from "processing" to "credited" after 2 seconds for clear delight
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsCredited(true);
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-8 shadow-2xl border border-[#e8dfd5] my-auto space-y-6 text-center">
        {/* Animated Celebration Icon */}
        <div className="w-16 h-16 rounded-full bg-[#f8f4ee] text-[#2b5b4b] mx-auto flex items-center justify-center shadow-xs border border-[#23755c]/20">
          <CheckCircle2 className="w-10 h-10 text-[#60a103]" />
        </div>

        <div>
          <h2 className="font-display font-black text-2xl sm:text-3xl text-[#2b5b4b]">
            {isBm ? 'Kain anda sudah terjual! 🎉' : 'Your fabric is sold! 🎉'}
          </h2>
          <p className="text-sm font-semibold text-[#315f4f] mt-2">
            {isBm ? 'Anda akan menerima:' : 'You will receive:'}
          </p>
          <div className="font-display font-black text-4xl sm:text-5xl text-[#2b5b4b] mt-1 tracking-tight">
            RM{amount}
          </div>
        </div>

        {/* Clear Status Indicator */}
        <div className="py-2">
          {!isCredited ? (
            <div className="bg-amber-50 text-amber-950 border border-amber-300 p-4 rounded-2xl flex items-center justify-center gap-2.5 text-sm font-bold animate-pulse">
              <span className="text-lg">🟡</span>
              <span>{isBm ? 'Bayaran sedang diproses...' : 'Payment is processing...'}</span>
            </div>
          ) : (
            <div className="bg-[#f8f4ee] text-[#2b5b4b] border border-[#60a103] p-4 rounded-2xl flex items-center justify-center gap-2.5 text-sm font-extrabold animate-in zoom-in-95 duration-300">
              <span className="text-lg">🟢</span>
              <span>
                {isBm
                  ? `RM${amount} sudah masuk ke pendapatan anda`
                  : `RM${amount} has been added to your earnings`}
              </span>
            </div>
          )}
        </div>

        {/* Action Button: “Lihat Pendapatan” (Buttons #60a103) */}
        <div className="space-y-2.5 pt-1">
          <button
            type="button"
            onClick={onGoToEarnings}
            className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
          >
            <span>{isBm ? 'Lihat Pendapatan' : 'View Earnings'}</span>
            <ArrowRight className="w-5 h-5 text-white" />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 text-center text-sm font-semibold text-[#315f4f] hover:text-[#2b5b4b] transition"
          >
            {isBm ? 'Tutup' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
