import React from 'react';
import { AppLanguage } from '../types';
import { Sparkles, ArrowRight, X } from 'lucide-react';

interface BuyerMatchModalProps {
  language: AppLanguage;
  onClose: () => void;
  onAcceptOrder: () => void;
}

export const BuyerMatchModal: React.FC<BuyerMatchModalProps> = ({
  language,
  onClose,
  onAcceptOrder
}) => {
  const isBm = language === 'bm';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] my-auto space-y-6">
        {/* Header Badge */}
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-2 bg-[#60a103]/15 text-[#2b5b4b] px-3.5 py-1 rounded-full text-xs font-extrabold border border-[#60a103]/30">
            <Sparkles className="w-4 h-4 text-[#60a103]" />
            <span>{isBm ? 'Berita Baik!' : 'Great News!'}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-[#f8f4ee] touch-target"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Title */}
        <div>
          <h2 className="font-display font-black text-2xl sm:text-3xl text-[#2b5b4b]">
            {isBm ? 'Ada Pembeli!' : 'You Have a Buyer!'}
          </h2>
          <p className="text-base font-bold text-[#23755c] mt-1.5">
            {isBm ? '“EcoCraft berminat dengan kain anda.”' : '“EcoCraft is interested in your fabric.”'}
          </p>
        </div>

        {/* Breakdown Card (Containers #f8f4ee) */}
        <div className="bg-[#f8f4ee] p-5 rounded-2xl border border-[#e8dfd5] space-y-3.5 text-sm">
          <div className="flex justify-between items-baseline border-b border-[#e8dfd5] pb-2">
            <span className="text-[#315f4f] font-medium">{isBm ? 'Mereka mahu:' : 'They want:'}</span>
            <strong className="text-[#2b5b4b] font-bold">10–20 {isBm ? 'helai (pcs) kain kapas' : 'pcs cotton fabric'}</strong>
          </div>

          <div className="flex justify-between items-baseline border-b border-[#e8dfd5] pb-2">
            <span className="text-[#315f4f] font-medium">{isBm ? 'Anda mempunyai:' : 'You have:'}</span>
            <strong className="text-[#2b5b4b] font-bold">12 {isBm ? 'helai (pcs)' : 'pcs'}</strong>
          </div>

          <div className="flex justify-between items-baseline border-b border-[#e8dfd5] pb-2">
            <span className="text-[#315f4f] font-medium">{isBm ? 'Anggaran bayaran pembeli:' : 'Buyer order price:'}</span>
            <span className="text-[#315f4f] font-semibold">RM60</span>
          </div>

          <div className="bg-white -mx-2 p-3.5 rounded-xl flex items-baseline justify-between border border-[#23755c]/20">
            <span className="text-xs font-bold text-[#23755c] uppercase tracking-wider">
              {isBm ? 'Pendapatan anda:' : 'Your earnings:'}
            </span>
            <span className="font-display font-black text-2xl text-[#2b5b4b]">
              RM18
            </span>
          </div>
        </div>

        <p className="text-xs text-[#315f4f]/80 text-center font-medium">
          {isBm
            ? 'Anda tidak perlu berunding. SewSmart telah menguruskan semuanya.'
            : 'No negotiation needed. SewSmart has handled everything.'}
        </p>

        {/* Large Primary Button: (Buttons #60a103) */}
        <button
          type="button"
          onClick={onAcceptOrder}
          className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
        >
          <span>{isBm ? 'Lihat Pesanan & Sahkan' : 'View Order & Confirm'}</span>
          <ArrowRight className="w-5 h-5 text-white" />
        </button>
      </div>
    </div>
  );
};
