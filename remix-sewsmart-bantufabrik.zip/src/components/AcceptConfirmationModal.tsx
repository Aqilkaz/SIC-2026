import React, { useState } from 'react';
import { Opportunity, AppLanguage } from '../types';
import { CheckCircle2, Navigation } from 'lucide-react';

interface AcceptConfirmationModalProps {
  opportunity: Opportunity;
  language: AppLanguage;
  onCloseToHome: () => void;
}

export const AcceptConfirmationModal: React.FC<AcceptConfirmationModalProps> = ({
  opportunity,
  language,
  onCloseToHome
}) => {
  const isBm = language === 'bm';
  const [showGuide, setShowGuide] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] my-auto space-y-6 text-center">
        {/* Success Icon */}
        <div className="w-16 h-16 rounded-full bg-[#f8f4ee] text-[#2b5b4b] mx-auto flex items-center justify-center shadow-xs border border-[#23755c]/20">
          <CheckCircle2 className="w-10 h-10 text-[#60a103]" />
        </div>

        {/* Title & Deadline */}
        <div>
          <h2 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
            {isBm ? 'Peluang ini sudah disimpan!' : 'Opportunity has been saved!'}
          </h2>
          <p className="text-sm font-semibold text-[#23755c] mt-1.5">
            {isBm
              ? `Sila ambil kain sebelum ${opportunity.deadline}.`
              : `Please collect the fabric before ${opportunity.deadline}.`}
          </p>
        </div>

        {/* Summary Card (Containers #f8f4ee) */}
        <div className="bg-[#f8f4ee] rounded-2xl p-4 border border-[#e8dfd5] text-left space-y-2.5 text-sm">
          <div className="flex items-start gap-2.5 text-[#315f4f]">
            <span className="text-base">📍</span>
            <div>
              <span className="font-bold block text-[#2b5b4b]">{isBm ? 'Lokasi' : 'Location'}</span>
              <span className="text-xs text-[#315f4f]">{opportunity.supplierAddress}</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-[#315f4f]">
            <span className="text-base">📅</span>
            <div>
              <span className="font-bold text-[#2b5b4b]">{isBm ? 'Tarikh' : 'Date'}: </span>
              <span className="text-[#315f4f]">{opportunity.deadline}</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-[#315f4f]">
            <span className="text-base">📦</span>
            <div>
              <span className="font-bold text-[#2b5b4b]">{isBm ? 'Kuantiti' : 'Quantity'}: </span>
              <span className="text-[#315f4f]">{opportunity.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'}</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-[#2b5b4b] bg-white border border-[#23755c]/20 p-2.5 rounded-xl">
            <span className="text-base">💰</span>
            <div>
              <span className="font-bold">{isBm ? 'Anggaran Pendapatan' : 'Estimated Earnings'}: </span>
              <strong className="text-base text-[#2b5b4b]">RM{opportunity.estEarnings}</strong>
            </div>
          </div>
        </div>

        {/* Pick-up Guide Expansion if user tapped "Lihat Cara Ambil" */}
        {showGuide && (
          <div className="bg-[#f8f4ee] p-4 rounded-2xl border border-[#23755c]/30 text-left space-y-2 animate-in fade-in duration-200 text-xs text-[#315f4f]">
            <h4 className="font-bold text-sm text-[#2b5b4b] flex items-center gap-1.5">
              <Navigation className="w-4 h-4 text-[#2b5b4b]" />
              <span>{isBm ? 'Panduan Mengambil Fabrik:' : 'Pickup Guidelines:'}</span>
            </h4>
            <p className="leading-relaxed text-[#315f4f]">
              {opportunity.pickupNote}
            </p>
            <div className="pt-1">
              <span className="font-bold text-[#2b5b4b] block">{isBm ? 'Masa Pengambilan:' : 'Pickup Hours:'}</span>
              <span className="text-[#315f4f]">10:00 AM – 4:30 PM (Isnin - Sabtu)</span>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-3 pt-1">
          {/* Large Button: "Lihat Cara Ambil" (Buttons #60a103) */}
          <button
            type="button"
            onClick={() => setShowGuide(!showGuide)}
            className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
          >
            <Navigation className="w-5 h-5 text-white" />
            <span>
              {showGuide
                ? (isBm ? 'Tutup Panduan Ambil' : 'Hide Pickup Guide')
                : (isBm ? 'Lihat Cara Ambil' : 'View How to Collect')}
            </span>
          </button>

          {/* Secondary Button: “Kembali ke Utama” */}
          <button
            type="button"
            onClick={onCloseToHome}
            className="w-full py-3 text-center text-sm font-bold text-[#315f4f] hover:text-[#2b5b4b] rounded-xl hover:bg-[#f8f4ee] transition"
          >
            {isBm ? 'Kembali ke Utama' : 'Back to Home'}
          </button>
        </div>
      </div>
    </div>
  );
};
