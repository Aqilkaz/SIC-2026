import React, { useState } from 'react';
import { AppLanguage } from '../types';
import {
  ArrowRight,
  Check,
  X,
  ChevronDown,
  ChevronUp,
  MapPin,
  Package,
  Sparkles,
  ShoppingBag,
  Coins,
  Smartphone,
  Clock,
  Home,
  CreditCard,
  Phone,
  MessageCircle,
  HelpCircle,
  Building2,
  Calendar,
  Scale,
  Camera,
  CheckCircle2,
  Bell,
  HeartHandshake
} from 'lucide-react';
import { RegistrationModal } from './RegistrationModal';

interface LandingPageViewProps {
  language: AppLanguage;
  onGoToCollector: (tab?: 'utama' | 'peluang') => void;
  onGoToSupplier: () => void;
  onGoToBuyer: () => void;
  onOpenHelpModal: () => void;
}

export const LandingPageView: React.FC<LandingPageViewProps> = ({
  language,
  onGoToCollector,
  onGoToSupplier,
  onGoToBuyer,
  onOpenHelpModal
}) => {
  const isBm = language === 'bm';
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Smooth scroll to How It Works section
  const handleScrollToHowItWorks = () => {
    const el = document.getElementById('section-how-it-works');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // FAQ list based exactly on requirements
  const faqs = [
    {
      q: isBm ? 'Perlu pandai menjahit?' : 'Do I need sewing skills?',
      a: isBm
        ? 'Tidak. Anda hanya perlu mengumpul dan mengasingkan fabrik.'
        : 'No. You only need to collect and sort the fabric.'
    },
    {
      q: isBm ? 'Perlu keluarkan modal?' : 'Do I need to put in capital?',
      a: isBm
        ? 'Tidak. Anda tidak perlu membeli fabrik terlebih dahulu.'
        : 'No. You do not need to purchase any fabric upfront.'
    },
    {
      q: isBm ? 'Perlu cari pembeli sendiri?' : 'Do I need to find buyers myself?',
      a: isBm
        ? 'Tidak. SewSmart membantu menghubungkan bahan anda dengan pembeli.'
        : 'No. SewSmart helps connect your materials directly with ready buyers.'
    },
    {
      q: isBm ? 'Boleh saya pilih peluang yang dekat dengan saya?' : 'Can I choose opportunities near me?',
      a: isBm
        ? 'Ya. Anda boleh melihat lokasi dan jarak sebelum menerima sesuatu peluang.'
        : 'Yes. You can review the exact location and distance before accepting any opportunity.'
    },
    {
      q: isBm ? 'Bagaimana saya dapat bayaran?' : 'How do I receive payments?',
      a: isBm
        ? 'Selepas fabrik terjual dan proses selesai, bayaran akan masuk ke akaun SewSmart anda.'
        : 'After the fabric is sold and completed, your payment is directly deposited into your SewSmart account.'
    },
    {
      q: isBm ? 'Kalau saya tidak tahu cara guna?' : 'What if I am not sure how to use it?',
      a: isBm
        ? 'Anda boleh tekan “Bantuan” pada bila-bila masa.'
        : 'You can tap “Help” at any time to receive step-by-step guidance.'
    }
  ];

  return (
    <div className="w-full space-y-12 sm:space-y-16 pb-20 text-[#1E2923]">
      {/* ========================================================================= */}
      {/* 1. HERO SECTION */}
      {/* ========================================================================= */}
      <section
        id="section-hero"
        className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-10 lg:p-12 border border-[#E5DFD7] shadow-xs text-center space-y-8"
      >
        {/* Friendly Sub-pill */}
        <div className="inline-flex items-center gap-2 bg-[#E8F0EC] text-[#2D6A4F] px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold border border-[#2D6A4F]/20">
          <span className="w-2.5 h-2.5 rounded-full bg-[#2D6A4F]"></span>
          <span>{isBm ? 'Kurang Sisa. Lebih Peluang.' : 'Less Waste. More Opportunities.'}</span>
        </div>

        {/* Main Headline */}
        <div className="space-y-3 max-w-3xl mx-auto">
          <h1 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl text-[#1B4332] tracking-tight leading-[1.15]">
            {isBm ? '“Tukar Sisa Fabrik Jadi Pendapatan.”' : '“Turn Fabric Waste Into Extra Income.”'}
          </h1>
          <p className="text-base sm:text-xl text-[#40534C] max-w-2xl mx-auto leading-relaxed font-medium">
            {isBm
              ? 'SewSmart membantu anda mendapatkan pendapatan tambahan dengan mengumpul dan mengasingkan fabrik yang masih boleh digunakan.'
              : 'SewSmart helps you earn extra income by collecting and sorting reusable fabrics from local businesses.'}
          </p>
        </div>

        {/* Simple Flow Visual: Sisa Fabrik → Ambil → Asingkan → Jual → Dapat Bayaran */}
        <div className="bg-white p-4 sm:p-6 rounded-2xl border border-[#E5DFD7] max-w-2xl mx-auto shadow-xs">
          <p className="text-xs font-bold text-[#52796F] uppercase tracking-wider mb-3">
            {isBm ? 'Perjalanan Mudah Anda' : 'Your Simple Journey'}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-xs sm:text-sm font-bold text-[#1B4332]">
            <span className="bg-[#FAF8F5] px-3 py-1.5 rounded-xl border border-[#E5DFD7]">
              📦 {isBm ? 'Sisa Fabrik' : 'Fabric Waste'}
            </span>
            <span className="text-[#2D6A4F] font-black">→</span>
            <span className="bg-[#FAF8F5] px-3 py-1.5 rounded-xl border border-[#E5DFD7]">
              🚶 {isBm ? 'Ambil' : 'Collect'}
            </span>
            <span className="text-[#2D6A4F] font-black">→</span>
            <span className="bg-[#FAF8F5] px-3 py-1.5 rounded-xl border border-[#E5DFD7]">
              🧺 {isBm ? 'Asingkan' : 'Sort'}
            </span>
            <span className="text-[#2D6A4F] font-black">→</span>
            <span className="bg-[#FAF8F5] px-3 py-1.5 rounded-xl border border-[#E5DFD7]">
              🛍️ {isBm ? 'Jual' : 'Sell'}
            </span>
            <span className="text-[#2D6A4F] font-black">→</span>
            <span className="bg-[#D8F3DC] text-[#1B4332] px-3.5 py-1.5 rounded-xl border border-[#2D6A4F]/30 font-extrabold shadow-2xs">
              💰 {isBm ? 'Dapat Bayaran' : 'Get Paid'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2 max-w-md mx-auto">
          {/* Primary button: “Mula Sekarang” */}
          <button
            id="btn-hero-mula-sekarang"
            type="button"
            onClick={() => setIsRegistrationOpen(true)}
            className="w-full sm:w-auto flex-1 bg-[#2D6A4F] hover:bg-[#235341] text-white font-extrabold text-base sm:text-lg py-4 px-8 rounded-2xl shadow-md transition flex items-center justify-center gap-2.5 touch-target cursor-pointer"
          >
            <span>{isBm ? 'Mula Sekarang' : 'Start Now'}</span>
            <ArrowRight className="w-5 h-5 text-white" />
          </button>

          {/* Secondary button: “Lihat Cara Ia Berfungsi” */}
          <button
            id="btn-hero-lihat-cara"
            type="button"
            onClick={handleScrollToHowItWorks}
            className="w-full sm:w-auto flex-1 bg-white hover:bg-[#FAF8F5] text-[#1B4332] font-bold text-base py-4 px-6 rounded-2xl border-2 border-[#E5DFD7] hover:border-[#2D6A4F]/40 transition touch-target cursor-pointer"
          >
            {isBm ? 'Lihat Cara Ia Berfungsi' : 'See How It Works'}
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. SIMPLE EXPLANATION */}
      {/* ========================================================================= */}
      <section
        id="section-explanation"
        className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-full">
            {isBm ? 'Penerangan Ringkas' : 'Brief Overview'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? '“SewSmart untuk apa?”' : '“What is SewSmart for?”'}
          </h2>
          <p className="text-base sm:text-lg text-[#40534C] leading-relaxed font-medium">
            {isBm
              ? 'Ada kilang dan hotel yang mempunyai fabrik yang masih boleh digunakan. SewSmart menghubungkan fabrik ini dengan anda.'
              : 'Hotels and factories have clean, reusable fabrics they no longer need. SewSmart connects this fabric directly with you.'}
          </p>
        </div>

        {/* Friendly Illustration / Visual Box */}
        <div className="bg-[#FAF8F5] rounded-2xl p-6 border border-[#E5DFD7] flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-[#E8F0EC] text-3xl flex items-center justify-center shrink-0 border border-[#2D6A4F]/20 shadow-2xs">
              👩‍🦱
            </div>
            <div>
              <h3 className="font-bold text-base text-[#1B4332]">
                {isBm ? 'Peluang Bersih & Selamat' : 'Clean & Safe Opportunities'}
              </h3>
              <p className="text-sm text-[#52796F]">
                {isBm
                  ? 'Kain cadar hotel, lebihan potongan kain kapas kilang, dan denim berkualiti.'
                  : 'Hotel linens, factory cotton offcuts, and clean denim ready for upcycling.'}
              </p>
            </div>
          </div>
          <div className="bg-white px-4 py-2.5 rounded-xl border border-[#E5DFD7] text-xs sm:text-sm font-bold text-[#2D6A4F] shrink-0">
            {isBm ? '✓ Tiada kos untuk anda' : '✓ Zero cost to you'}
          </div>
        </div>

        {/* 3 Short Points */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
          {/* Point 1: Cari */}
          <div className="bg-[#FAF8F5] rounded-2xl p-6 border border-[#E5DFD7] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#2D6A4F] text-white font-extrabold text-base flex items-center justify-center">
              1
            </div>
            <h3 className="font-extrabold text-lg text-[#1B4332]">
              {isBm ? 'Cari' : 'Find'}
            </h3>
            <p className="text-sm text-[#40534C] leading-relaxed font-medium">
              {isBm
                ? 'Cari fabrik yang boleh diambil berdekatan anda.'
                : 'Find available fabrics to collect near your home.'}
            </p>
          </div>

          {/* Point 2: Ambil & Asingkan */}
          <div className="bg-[#FAF8F5] rounded-2xl p-6 border border-[#E5DFD7] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#2D6A4F] text-white font-extrabold text-base flex items-center justify-center">
              2
            </div>
            <h3 className="font-extrabold text-lg text-[#1B4332]">
              {isBm ? 'Ambil & Asingkan' : 'Collect & Sort'}
            </h3>
            <p className="text-sm text-[#40534C] leading-relaxed font-medium">
              {isBm
                ? 'Ambil fabrik, kemudian asingkan mengikut jenis dan keadaan.'
                : 'Pick up the fabric, then sort it by type and condition.'}
            </p>
          </div>

          {/* Point 3: Dapat Bayaran */}
          <div className="bg-[#FAF8F5] rounded-2xl p-6 border border-[#E5DFD7] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#2D6A4F] text-white font-extrabold text-base flex items-center justify-center">
              3
            </div>
            <h3 className="font-extrabold text-lg text-[#1B4332]">
              {isBm ? 'Dapat Bayaran' : 'Get Paid'}
            </h3>
            <p className="text-sm text-[#40534C] leading-relaxed font-medium">
              {isBm
                ? 'Fabrik anda dijual kepada pembeli dan anda menerima bayaran.'
                : 'Your fabric is bought by eco-crafters and you receive payment.'}
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. “SIAPA BOLEH SERTAI?” */}
      {/* ========================================================================= */}
      <section
        id="section-who-can-join"
        className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-white px-3 py-1 rounded-full border border-[#E5DFD7]">
            {isBm ? 'Penyertaan Terbuka' : 'Open Participation'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? '“SewSmart sesuai untuk anda jika…”' : '“SewSmart is right for you if…”'}
          </h2>
          <p className="text-sm sm:text-base text-[#40534C]">
            {isBm
              ? 'Sesiapa sahaja boleh bermula tanpa tekanan.'
              : 'Anyone can start earning without pressure or complicated requirements.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
          {/* Card 1 */}
          <div className="bg-white rounded-2xl p-6 border border-[#E5DFD7] shadow-xs flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-[#D8F3DC] text-[#2D6A4F] flex items-center justify-center shrink-0">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-base sm:text-lg text-[#1B4332]">
                {isBm ? 'Mahu pendapatan tambahan' : 'Want extra income'}
              </h3>
              <p className="text-sm text-[#40534C] leading-relaxed">
                {isBm
                  ? 'Anda boleh buat mengikut masa yang sesuai untuk anda.'
                  : 'You can do this at your own pace, on days and times that fit your schedule.'}
              </p>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white rounded-2xl p-6 border border-[#E5DFD7] shadow-xs flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-[#D8F3DC] text-[#2D6A4F] flex items-center justify-center shrink-0">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-base sm:text-lg text-[#1B4332]">
                {isBm ? 'Tidak mempunyai modal' : 'Zero capital required'}
              </h3>
              <p className="text-sm text-[#40534C] leading-relaxed">
                {isBm
                  ? 'Anda tidak perlu membeli stok sendiri.'
                  : 'You never have to spend your own savings to buy stock.'}
              </p>
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white rounded-2xl p-6 border border-[#E5DFD7] shadow-xs flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-[#D8F3DC] text-[#2D6A4F] flex items-center justify-center shrink-0">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-base sm:text-lg text-[#1B4332]">
                {isBm ? 'Tidak pandai menjahit' : 'No sewing skills needed'}
              </h3>
              <p className="text-sm text-[#40534C] leading-relaxed">
                {isBm
                  ? 'Anda tidak perlu menjahit atau menghasilkan produk.'
                  : 'You do not need to sew clothes or produce handicrafts.'}
              </p>
            </div>
          </div>

          {/* Card 4 */}
          <div className="bg-white rounded-2xl p-6 border border-[#E5DFD7] shadow-xs flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-[#D8F3DC] text-[#2D6A4F] flex items-center justify-center shrink-0">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-base sm:text-lg text-[#1B4332]">
                {isBm ? 'Mahu mula secara kecil-kecilan' : 'Want to start small'}
              </h3>
              <p className="text-sm text-[#40534C] leading-relaxed">
                {isBm
                  ? 'Anda boleh mula dengan satu peluang dahulu.'
                  : 'You can test the waters with just one small opportunity first.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. HOW TO REGISTER (4 SIMPLE STEPS ONLY) */}
      {/* ========================================================================= */}
      <section
        id="section-how-to-register"
        className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-full">
            {isBm ? 'Pendaftaran Mudah' : 'Simple Registration'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? 'Cara Daftar SewSmart' : 'How to Register on SewSmart'}
          </h2>
          <p className="text-sm sm:text-base text-[#40534C]">
            {isBm
              ? 'Hanya 4 langkah ringkas untuk mula menjana pendapatan.'
              : 'Just 4 easy steps to start earning.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* LANGKAH 1 */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 border border-[#E5DFD7] space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-lg uppercase tracking-wider">
                {isBm ? 'Langkah 1' : 'Step 1'}
              </span>
              <span className="text-2xl">👆</span>
            </div>
            <div>
              <h3 className="font-extrabold text-xl text-[#1B4332]">
                {isBm ? 'Tekan “Mula Sekarang”' : 'Tap “Start Now”'}
              </h3>
              <p className="text-sm text-[#40534C] mt-1">
                {isBm
                  ? 'Tekan butang Mula Sekarang untuk membuat akaun.'
                  : 'Tap the Start Now button to create your free account.'}
              </p>
            </div>

            {/* Visual preview of button */}
            <div className="pt-2">
              <div
                onClick={() => setIsRegistrationOpen(true)}
                className="bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-sm py-3 px-5 rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition"
              >
                <span>{isBm ? 'Mula Sekarang' : 'Start Now'}</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* LANGKAH 2 */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 border border-[#E5DFD7] space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-lg uppercase tracking-wider">
                {isBm ? 'Langkah 2' : 'Step 2'}
              </span>
              <span className="text-2xl">👩</span>
            </div>
            <div>
              <h3 className="font-extrabold text-xl text-[#1B4332]">
                {isBm ? 'Pilih “Saya Mahu Jana Pendapatan”' : 'Select “I Want To Earn Income”'}
              </h3>
              <p className="text-sm text-[#40534C] mt-1">
                {isBm
                  ? 'Pilih pilihan ini jika anda mahu mengumpul fabrik dan mendapatkan pendapatan.'
                  : 'Choose this option to collect fabric and earn extra money.'}
              </p>
            </div>

            {/* Welcoming role box (No B40 role label!) */}
            <div className="bg-white p-3.5 rounded-xl border-2 border-[#2D6A4F] flex items-center justify-between">
              <div>
                <span className="font-extrabold text-sm text-[#1B4332] block">
                  {isBm ? 'Saya Mahu Jana Pendapatan' : 'I Want To Earn Income'}
                </span>
                <span className="text-xs text-[#52796F]">
                  {isBm ? 'Untuk pengumpul fabrik.' : 'For fabric collectors.'}
                </span>
              </div>
              <div className="w-6 h-6 rounded-full bg-[#2D6A4F] text-white flex items-center justify-center">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>
          </div>

          {/* LANGKAH 3 */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 border border-[#E5DFD7] space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-lg uppercase tracking-wider">
                {isBm ? 'Langkah 3' : 'Step 3'}
              </span>
              <span className="text-2xl">📝</span>
            </div>
            <div>
              <h3 className="font-extrabold text-xl text-[#1B4332]">
                {isBm ? 'Isi Maklumat Anda' : 'Fill In Your Details'}
              </h3>
              <p className="text-sm text-[#40534C] mt-1">
                {isBm
                  ? 'Hanya maklumat penting yang diperlukan.'
                  : 'Only simple, necessary details are requested.'}
              </p>
            </div>

            {/* Registration Form Preview */}
            <div className="bg-white p-3.5 rounded-xl border border-[#E5DFD7] space-y-2 text-xs">
              <div className="flex justify-between items-center bg-[#FAF8F5] p-2 rounded-lg border border-[#E5DFD7]">
                <span className="text-[#52796F] font-bold">{isBm ? 'Nama:' : 'Name:'}</span>
                <span className="font-extrabold text-[#1B4332]">Aina</span>
              </div>
              <div className="flex justify-between items-center bg-[#FAF8F5] p-2 rounded-lg border border-[#E5DFD7]">
                <span className="text-[#52796F] font-bold">{isBm ? 'Nombor Telefon:' : 'Phone:'}</span>
                <span className="font-extrabold text-[#1B4332]">012-3456789</span>
              </div>
              <div className="flex justify-between items-center bg-[#FAF8F5] p-2 rounded-lg border border-[#E5DFD7]">
                <span className="text-[#52796F] font-bold">{isBm ? 'Kawasan:' : 'Area:'}</span>
                <span className="font-extrabold text-[#1B4332]">Selangor ▼</span>
              </div>
              <div className="text-center pt-1 font-bold text-[#2D6A4F]">
                {isBm ? 'Kemudian tekan “Teruskan”' : 'Then tap “Continue”'}
              </div>
            </div>
          </div>

          {/* LANGKAH 4 */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 border border-[#E5DFD7] space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-lg uppercase tracking-wider">
                {isBm ? 'Langkah 4' : 'Step 4'}
              </span>
              <span className="text-2xl">🎉</span>
            </div>
            <div>
              <h3 className="font-extrabold text-xl text-[#1B4332]">
                {isBm ? 'Akaun Anda Siap!' : 'Your Account is Ready!'}
              </h3>
              <p className="text-sm text-[#40534C] mt-1">
                {isBm
                  ? 'Sekarang anda boleh mula mencari peluang fabrik berdekatan.'
                  : 'Now you can immediately start finding nearby fabric opportunities.'}
              </p>
            </div>

            {/* Visual Success & Cari Peluang button */}
            <div className="space-y-2.5 pt-1">
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#2D6A4F] bg-[#D8F3DC] px-3 py-1.5 rounded-full border border-[#2D6A4F]/20">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{isBm ? 'Akaun berjaya dibuat!' : 'Account created successfully!'}</span>
              </div>
              <button
                type="button"
                onClick={() => onGoToCollector('peluang')}
                className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-sm py-3 px-4 rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition"
              >
                <span>{isBm ? 'Cari Peluang' : 'Find Opportunities'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. ROLE SELECTION */}
      {/* ========================================================================= */}
      <section
        id="section-role-selection"
        className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-white px-3 py-1 rounded-full border border-[#E5DFD7]">
            {isBm ? 'Pilihan Pengguna' : 'User Roles'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? 'Pilih Cara Anda Menggunakan SewSmart' : 'Choose How You Use SewSmart'}
          </h2>
          <p className="text-sm sm:text-base text-[#40534C]">
            {isBm
              ? 'Platform ini menghubungkan tiga pihak untuk manfaat bersama.'
              : 'Connecting community collectors, suppliers, and craft buyers.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
          {/* Role 1: COLLECTOR (MAIN CARD - VISUALLY EMPHASIZED) */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border-3 border-[#2D6A4F] shadow-lg flex flex-col justify-between space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-[#2D6A4F] text-white text-[11px] font-extrabold px-3 py-1 rounded-bl-xl tracking-wider uppercase">
              {isBm ? 'Pilihan Utama' : 'Main Focus'}
            </div>

            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#E8F0EC] border border-[#2D6A4F]/20 flex items-center justify-center text-3xl shadow-xs">
                👩
              </div>
              <div>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-[#1B4332]">
                  {isBm ? '“Saya Mahu Jana Pendapatan”' : '“I Want To Earn Income”'}
                </h3>
                <p className="text-sm sm:text-base text-[#40534C] mt-2 leading-relaxed font-medium">
                  {isBm
                    ? 'Kumpul dan asingkan fabrik untuk mendapatkan pendapatan tambahan.'
                    : 'Collect and sort fabrics to earn additional flexible income.'}
                </p>
              </div>

              <div className="bg-[#FAF8F5] p-3 rounded-xl border border-[#E5DFD7] text-xs text-[#2D6A4F] font-bold space-y-1">
                <div>✓ {isBm ? 'Tanpa modal & tanpa beli stok' : 'Zero capital & no stock purchase'}</div>
                <div>✓ {isBm ? 'Kerja mengikut masa sendiri' : 'Work on your own schedule'}</div>
              </div>
            </div>

            <button
              id="btn-choose-collector"
              type="button"
              onClick={() => setIsRegistrationOpen(true)}
              className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-extrabold text-base py-4 px-6 rounded-2xl shadow-md transition flex items-center justify-center gap-2 touch-target cursor-pointer"
            >
              <span>{isBm ? 'Pilih Ini' : 'Choose This'}</span>
              <ArrowRight className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Role 2: SUPPLIER */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#FAF8F5] border border-[#E5DFD7] flex items-center justify-center text-3xl shadow-2xs">
                🏭
              </div>
              <div>
                <h3 className="font-display font-bold text-lg sm:text-xl text-[#1B4332]">
                  {isBm ? '“Saya Ada Sisa Fabrik”' : '“I Have Fabric Waste”'}
                </h3>
                <p className="text-sm text-[#40534C] mt-2 leading-relaxed font-medium">
                  {isBm
                    ? 'Saya mewakili kilang, hotel atau perniagaan yang mempunyai fabrik yang masih boleh digunakan.'
                    : 'I represent a factory, hotel, or business with clean, reusable fabric waste.'}
                </p>
              </div>
            </div>

            <button
              id="btn-choose-supplier"
              type="button"
              onClick={onGoToSupplier}
              className="w-full bg-[#FAF8F5] hover:bg-[#E8F0EC] text-[#1B4332] font-bold text-base py-3.5 px-6 rounded-2xl border border-[#E5DFD7] transition touch-target cursor-pointer"
            >
              {isBm ? 'Pilih Ini' : 'Choose This'}
            </button>
          </div>

          {/* Role 3: BUYER */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#FAF8F5] border border-[#E5DFD7] flex items-center justify-center text-3xl shadow-2xs">
                🛍️
              </div>
              <div>
                <h3 className="font-display font-bold text-lg sm:text-xl text-[#1B4332]">
                  {isBm ? '“Saya Mahu Beli Fabrik”' : '“I Want To Buy Fabric”'}
                </h3>
                <p className="text-sm text-[#40534C] mt-2 leading-relaxed font-medium">
                  {isBm
                    ? 'Cari fabrik terpakai untuk kraftangan, perniagaan atau produk upcycle.'
                    : 'Source sorted reclaimed fabrics for craft, enterprise, or upcycled products.'}
                </p>
              </div>
            </div>

            <button
              id="btn-choose-buyer"
              type="button"
              onClick={onGoToBuyer}
              className="w-full bg-[#FAF8F5] hover:bg-[#E8F0EC] text-[#1B4332] font-bold text-base py-3.5 px-6 rounded-2xl border border-[#E5DFD7] transition touch-target cursor-pointer"
            >
              {isBm ? 'Pilih Ini' : 'Choose This'}
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. AFTER REGISTRATION: “APA YANG PERLU SAYA BUAT?” (MOST IMPORTANT SECTION) */}
      {/* ========================================================================= */}
      <section
        id="section-how-it-works"
        className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-10"
      >
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-[#E8F0EC] px-3.5 py-1 rounded-full">
            {isBm ? 'Panduan Lengkap' : 'Step-by-Step Guide'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl lg:text-5xl text-[#1B4332]">
            {isBm ? 'Selepas Daftar, Apa Saya Perlu Buat?' : 'After Registering, What Do I Need To Do?'}
          </h2>
          <p className="text-base sm:text-lg text-[#40534C] font-medium leading-relaxed">
            {isBm
              ? 'Ikuti 5 langkah mudah ini dari mula hingga anda menerima bayaran.'
              : 'Follow these 5 simple steps from the start until money arrives in your account.'}
          </p>
        </div>

        {/* 5 Steps Stacked Cards with visual interface mockups */}
        <div className="space-y-6 max-w-3xl mx-auto">
          {/* STEP 1: CARI PELUANG */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#E8F0EC] text-[#2D6A4F] flex items-center justify-center text-xl font-black">
                  📍
                </div>
                <div>
                  <span className="text-xs font-black uppercase tracking-wider text-[#2D6A4F]">
                    01 — CARI PELUANG
                  </span>
                  <h3 className="font-display font-extrabold text-xl sm:text-2xl text-[#1B4332]">
                    {isBm ? '“Cari fabrik berdekatan.”' : '“Find nearby fabrics.”'}
                  </h3>
                </div>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#40534C] leading-relaxed">
              {isBm
                ? 'Lihat fabrik yang boleh anda ambil di kawasan anda.'
                : 'Browse available fabrics you can collect in your neighborhood.'}
            </p>

            {/* Example Card */}
            <div className="bg-white rounded-2xl p-4.5 border border-[#E5DFD7] space-y-3 shadow-2xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-extrabold text-base text-[#1B4332] block">Kain Kapas</span>
                  <span className="text-xs text-[#52796F]">20 kg · 5 km dari lokasi anda</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#52796F] block">{isBm ? 'Anggaran pendapatan:' : 'Est. earnings:'}</span>
                  <span className="text-lg font-black text-[#2D6A4F]">RM35</span>
                </div>
              </div>

              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => onGoToCollector('peluang')}
                  className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-sm py-2.5 px-4 rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition"
                >
                  <span>{isBm ? 'Lihat Peluang' : 'View Opportunity'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* STEP 2: AMBIL FABRIK */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#E8F0EC] text-[#2D6A4F] flex items-center justify-center text-xl font-black">
                📦
              </div>
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-[#2D6A4F]">
                  02 — AMBIL FABRIK
                </span>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-[#1B4332]">
                  {isBm ? '“Pergi ke lokasi dan ambil fabrik.”' : '“Go to the location and collect fabric.”'}
                </h3>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#40534C] leading-relaxed">
              {isBm
                ? 'Ikut lokasi dan arahan yang diberikan.'
                : 'Follow the clear pickup location, contact, and instructions.'}
            </p>

            {/* Detail Preview */}
            <div className="bg-white rounded-2xl p-4.5 border border-[#E5DFD7] grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs sm:text-sm">
              <div className="flex items-center gap-2 text-[#1B4332] font-semibold">
                <MapPin className="w-4 h-4 text-[#2D6A4F] shrink-0" />
                <span>{isBm ? '📍 Lokasi: Hotel Seri Malaysia' : '📍 Location: Hotel Seri Malaysia'}</span>
              </div>
              <div className="flex items-center gap-2 text-[#1B4332] font-semibold">
                <Calendar className="w-4 h-4 text-[#2D6A4F] shrink-0" />
                <span>{isBm ? '📅 Tarikh akhir: Jumaat, 5 petang' : '📅 Deadline: Friday, 5 PM'}</span>
              </div>
              <div className="flex items-center gap-2 text-[#1B4332] font-semibold">
                <Scale className="w-4 h-4 text-[#2D6A4F] shrink-0" />
                <span>{isBm ? '⚖️ Jumlah fabrik: 20 kg' : '⚖️ Fabric amount: 20 kg'}</span>
              </div>
            </div>

            {/* Important Reassurance */}
            <div className="bg-[#D8F3DC] p-3.5 rounded-xl border border-[#2D6A4F]/20 text-xs sm:text-sm font-bold text-[#1B4332] flex items-center gap-2">
              <Check className="w-4 h-4 text-[#2D6A4F] shrink-0 stroke-[3]" />
              <span>{isBm ? '“Anda tidak perlu membeli atau menjahit fabrik.”' : '“You never need to buy or sew the fabric.”'}</span>
            </div>
          </div>

          {/* STEP 3: ASINGKAN FABRIK */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#E8F0EC] text-[#2D6A4F] flex items-center justify-center text-xl font-black">
                🧺
              </div>
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-[#2D6A4F]">
                  03 — ASINGKAN FABRIK
                </span>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-[#1B4332]">
                  {isBm ? '“Asingkan fabrik.”' : '“Sort the fabric.”'}
                </h3>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#40534C] leading-relaxed">
              {isBm
                ? 'Pilih jenis dan keadaan fabrik. Ambil gambar dan masukkan berat.'
                : 'Select fabric type and condition. Snap a photo and confirm weight.'}
            </p>

            {/* Simple Interface Mockup */}
            <div className="bg-white rounded-2xl p-5 border border-[#E5DFD7] space-y-3 shadow-2xs">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E5DFD7]">
                  <span className="text-[#52796F] block font-medium">{isBm ? 'Jenis:' : 'Type:'}</span>
                  <span className="font-extrabold text-[#1B4332] text-sm">Kapas</span>
                </div>
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E5DFD7]">
                  <span className="text-[#52796F] block font-medium">{isBm ? 'Keadaan:' : 'Condition:'}</span>
                  <span className="font-extrabold text-[#1B4332] text-sm">Baik</span>
                </div>
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E5DFD7]">
                  <span className="text-[#52796F] block font-medium">{isBm ? 'Berat:' : 'Weight:'}</span>
                  <span className="font-extrabold text-[#1B4332] text-sm">12 kg</span>
                </div>
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E5DFD7] flex items-center gap-1.5 font-bold text-[#2D6A4F]">
                  <Camera className="w-4 h-4" />
                  <span>{isBm ? '📷 Foto Dimuat' : '📷 Photo Added'}</span>
                </div>
              </div>

              <div className="w-full bg-[#E8F0EC] text-[#2D6A4F] font-bold text-xs sm:text-sm py-2 px-4 rounded-xl text-center border border-[#2D6A4F]/20">
                {isBm ? 'Tekan butang “Selesai”' : 'Tap “Complete”'}
              </div>
            </div>
          </div>

          {/* STEP 4: TUNGGU PEMBELI */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#E8F0EC] text-[#2D6A4F] flex items-center justify-center text-xl font-black">
                🛍️
              </div>
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-[#2D6A4F]">
                  04 — TUNGGU PEMBELI
                </span>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-[#1B4332]">
                  {isBm ? '“SewSmart bantu cari pembeli.”' : '“SewSmart helps find buyers.”'}
                </h3>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#40534C] leading-relaxed">
              {isBm
                ? 'Anda tidak perlu mencari pembeli sendiri.'
                : 'You do not have to search for or message craft buyers on your own.'}
            </p>

            {/* Notification Preview */}
            <div className="bg-white rounded-2xl p-5 border-2 border-[#2D6A4F] space-y-3 shadow-sm">
              <div className="flex items-center gap-2 text-sm font-extrabold text-[#2D6A4F]">
                <Bell className="w-4 h-4 text-[#2D6A4F]" />
                <span>🎉 {isBm ? 'Ada pembeli!' : 'Buyer matched!'}</span>
              </div>
              <div className="text-xs sm:text-sm text-[#40534C] font-medium">
                {isBm
                  ? 'EcoCraft berminat dengan 12 kg kain kapas.'
                  : 'EcoCraft is interested in 12 kg sorted cotton fabric.'}
              </div>
              <div className="flex items-center justify-between bg-[#FAF8F5] p-3 rounded-xl border border-[#E5DFD7]">
                <div>
                  <span className="text-xs text-[#52796F] block">{isBm ? 'Anggaran bayaran:' : 'Buyer order:'}</span>
                  <span className="font-bold text-sm text-[#1B4332]">RM60</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#52796F] block">{isBm ? 'Pendapatan anda:' : 'Your earnings:'}</span>
                  <span className="text-xl font-black text-[#2D6A4F]">RM18</span>
                </div>
              </div>
              <div className="w-full bg-[#2D6A4F] text-white font-bold text-xs sm:text-sm py-2 px-4 rounded-xl text-center">
                {isBm ? 'Lihat Pesanan' : 'View Order'}
              </div>
            </div>
          </div>

          {/* STEP 5: DAPAT BAYARAN */}
          <div className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-8 border border-[#E5DFD7] shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#E8F0EC] text-[#2D6A4F] flex items-center justify-center text-xl font-black">
                💰
              </div>
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-[#2D6A4F]">
                  05 — DAPAT BAYARAN
                </span>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-[#1B4332]">
                  {isBm ? '“Dapat bayaran.”' : '“Get paid.”'}
                </h3>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#40534C] leading-relaxed">
              {isBm
                ? 'Selepas jualan selesai, bayaran anda akan masuk ke akaun SewSmart.'
                : 'After the sale is complete, your payment is directly deposited into your SewSmart account.'}
            </p>

            {/* Earnings Receipt Mockup */}
            <div className="bg-white rounded-2xl p-5 border border-[#E5DFD7] text-center space-y-2 shadow-2xs">
              <span className="text-3xl sm:text-4xl font-black text-[#2D6A4F] block">
                + RM18
              </span>
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#2D6A4F] bg-[#D8F3DC] px-3 py-1 rounded-full border border-[#2D6A4F]/20">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{isBm ? 'Bayaran diterima ✓' : 'Payment received ✓'}</span>
              </div>
              <p className="text-xs sm:text-sm text-[#40534C] font-semibold pt-1">
                {isBm ? '“Anda boleh keluarkan wang anda.”' : '“You can withdraw your money anytime.”'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 7. VERY SIMPLE VISUAL JOURNEY: “Semudah Ini” */}
      {/* ========================================================================= */}
      <section
        id="section-semudah-ini"
        className="bg-[#1B4332] text-white rounded-3xl p-6 sm:p-10 shadow-md text-center space-y-8"
      >
        <div className="space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#D8F3DC] bg-white/10 px-3 py-1 rounded-full">
            {isBm ? 'Ringkasan Proses' : 'Process Summary'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-white">
            {isBm ? '“Semudah Ini”' : '“As Simple As This”'}
          </h2>
        </div>

        {/* Large Visual Steps */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-2 max-w-3xl mx-auto">
          <div className="flex-1 bg-white/10 backdrop-blur-xs rounded-2xl p-4 border border-white/15 w-full sm:w-auto">
            <span className="text-2xl block mb-1">📍</span>
            <span className="font-black text-sm tracking-wider">{isBm ? 'CARI' : 'FIND'}</span>
          </div>
          <span className="text-white/40 font-bold text-xl sm:text-2xl rotate-90 sm:rotate-0">↓</span>
          <div className="flex-1 bg-white/10 backdrop-blur-xs rounded-2xl p-4 border border-white/15 w-full sm:w-auto">
            <span className="text-2xl block mb-1">📦</span>
            <span className="font-black text-sm tracking-wider">{isBm ? 'AMBIL' : 'COLLECT'}</span>
          </div>
          <span className="text-white/40 font-bold text-xl sm:text-2xl rotate-90 sm:rotate-0">↓</span>
          <div className="flex-1 bg-white/10 backdrop-blur-xs rounded-2xl p-4 border border-white/15 w-full sm:w-auto">
            <span className="text-2xl block mb-1">🧺</span>
            <span className="font-black text-sm tracking-wider">{isBm ? 'ASINGKAN' : 'SORT'}</span>
          </div>
          <span className="text-white/40 font-bold text-xl sm:text-2xl rotate-90 sm:rotate-0">↓</span>
          <div className="flex-1 bg-white/10 backdrop-blur-xs rounded-2xl p-4 border border-white/15 w-full sm:w-auto">
            <span className="text-2xl block mb-1">🛍️</span>
            <span className="font-black text-sm tracking-wider">{isBm ? 'JUAL' : 'SELL'}</span>
          </div>
          <span className="text-white/40 font-bold text-xl sm:text-2xl rotate-90 sm:rotate-0">↓</span>
          <div className="flex-1 bg-[#D8F3DC] text-[#1B4332] rounded-2xl p-4 border border-white/30 shadow-md w-full sm:w-auto">
            <span className="text-2xl block mb-1">💰</span>
            <span className="font-black text-sm tracking-wider">{isBm ? 'DAPAT BAYARAN' : 'GET PAID'}</span>
          </div>
        </div>

        {/* Strongest Message */}
        <div className="bg-white/10 p-5 rounded-2xl max-w-2xl mx-auto border border-white/20">
          <p className="text-base sm:text-lg font-bold text-[#D8F3DC] leading-relaxed">
            {isBm
              ? '“Anda tidak perlu menjahit. Anda tidak perlu membeli stok. Anda tidak perlu mencari pembeli.”'
              : '“You don’t need to sew. You don’t need to buy stock. You don’t need to find buyers.”'}
          </p>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 8. “APA YANG SAYA PERLUKAN?” */}
      {/* ========================================================================= */}
      <section
        id="section-what-do-i-need"
        className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-full">
            {isBm ? 'Keperluan Mudah' : 'Simple Requirements'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? '“Apa Yang Saya Perlukan?”' : '“What Do I Need?”'}
          </h2>
          <p className="text-sm sm:text-base text-[#40534C]">
            {isBm
              ? 'Hanya 4 perkara mudah yang anda sudah miliki.'
              : 'Only 4 simple items you already have around you.'}
          </p>
        </div>

        {/* 4 Simple Items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#FAF8F5] rounded-2xl p-5 border border-[#E5DFD7] space-y-2 text-center sm:text-left">
            <div className="w-12 h-12 rounded-xl bg-white border border-[#E5DFD7] flex items-center justify-center text-2xl mx-auto sm:mx-0 shadow-2xs">
              📱
            </div>
            <h3 className="font-extrabold text-base text-[#1B4332]">
              {isBm ? 'Telefon' : 'Smartphone'}
            </h3>
            <p className="text-xs sm:text-sm text-[#40534C] leading-relaxed">
              {isBm ? 'Untuk menggunakan SewSmart.' : 'To browse opportunities and use SewSmart.'}
            </p>
          </div>

          <div className="bg-[#FAF8F5] rounded-2xl p-5 border border-[#E5DFD7] space-y-2 text-center sm:text-left">
            <div className="w-12 h-12 rounded-xl bg-white border border-[#E5DFD7] flex items-center justify-center text-2xl mx-auto sm:mx-0 shadow-2xs">
              🚶
            </div>
            <h3 className="font-extrabold text-base text-[#1B4332]">
              {isBm ? 'Masa' : 'A Little Time'}
            </h3>
            <p className="text-xs sm:text-sm text-[#40534C] leading-relaxed">
              {isBm ? 'Pilih peluang yang sesuai dengan masa anda.' : 'Pick opportunities that match your free hours.'}
            </p>
          </div>

          <div className="bg-[#FAF8F5] rounded-2xl p-5 border border-[#E5DFD7] space-y-2 text-center sm:text-left">
            <div className="w-12 h-12 rounded-xl bg-white border border-[#E5DFD7] flex items-center justify-center text-2xl mx-auto sm:mx-0 shadow-2xs">
              🧺
            </div>
            <h3 className="font-extrabold text-base text-[#1B4332]">
              {isBm ? 'Tempat Untuk Asingkan' : 'A Space to Sort'}
            </h3>
            <p className="text-xs sm:text-sm text-[#40534C] leading-relaxed">
              {isBm ? 'Anda hanya perlu mengasingkan fabrik yang dikumpul.' : 'A clean corner at home to sort collected fabrics.'}
            </p>
          </div>

          <div className="bg-[#FAF8F5] rounded-2xl p-5 border border-[#E5DFD7] space-y-2 text-center sm:text-left">
            <div className="w-12 h-12 rounded-xl bg-white border border-[#E5DFD7] flex items-center justify-center text-2xl mx-auto sm:mx-0 shadow-2xs">
              💳
            </div>
            <h3 className="font-extrabold text-base text-[#1B4332]">
              {isBm ? 'Akaun Pembayaran' : 'Bank Account / DuitNow'}
            </h3>
            <p className="text-xs sm:text-sm text-[#40534C] leading-relaxed">
              {isBm ? 'Untuk menerima bayaran.' : 'To safely withdraw and receive your earnings.'}
            </p>
          </div>
        </div>

        {/* Clear Contrast: “Tak perlu…” */}
        <div className="bg-[#FAF8F5] rounded-2xl p-6 border border-[#E5DFD7] space-y-4">
          <h3 className="font-display font-extrabold text-lg sm:text-xl text-[#1B4332]">
            {isBm ? '“Tak perlu…”' : '“You DO NOT need…”'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-sm font-bold text-[#8A3B3B]">
            <div className="bg-white p-3 rounded-xl border border-[#E5DFD7] flex items-center gap-2.5">
              <span className="text-base">❌</span>
              <span>{isBm ? 'Modal besar' : 'Any capital'}</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-[#E5DFD7] flex items-center gap-2.5">
              <span className="text-base">❌</span>
              <span>{isBm ? 'Mesin jahit' : 'Sewing machine'}</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-[#E5DFD7] flex items-center gap-2.5">
              <span className="text-base">❌</span>
              <span>{isBm ? 'Kemahiran menjahit' : 'Sewing skills'}</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-[#E5DFD7] flex items-center gap-2.5">
              <span className="text-base">❌</span>
              <span>{isBm ? 'Kedai fizikal' : 'A shop or store'}</span>
            </div>
            <div className="bg-white p-3 rounded-xl border border-[#E5DFD7] flex items-center gap-2.5 sm:col-span-2">
              <span className="text-base">❌</span>
              <span>{isBm ? 'Cari pelanggan sendiri' : 'Finding customers yourself'}</span>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 9. SAMPLE FIRST EXPERIENCE: “Contoh: Hari Pertama Aina di SewSmart” */}
      {/* ========================================================================= */}
      <section
        id="section-sample-experience"
        className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-white px-3 py-1 rounded-full border border-[#E5DFD7]">
            {isBm ? 'Kisah Nyata Mudah' : 'Real-Life Scenario'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? '“Contoh: Hari Pertama Aina di SewSmart”' : '“Example: Aina’s First Day on SewSmart”'}
          </h2>
          <p className="text-sm sm:text-base text-[#40534C]">
            {isBm
              ? 'Bagaimana seorang ibu rumah tangga seperti Aina menjana RM35 dalam sehari.'
              : 'How a homemaker like Aina earned RM35 in a single day.'}
          </p>
        </div>

        {/* Vertical Visual Storyline */}
        <div className="max-w-xl mx-auto space-y-3">
          {/* Step 1: Pagi */}
          <div className="bg-white p-4.5 rounded-2xl border border-[#E5DFD7] flex items-start gap-4 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EC] text-lg flex items-center justify-center shrink-0">
              ☀️
            </div>
            <div className="flex-1">
              <span className="text-xs font-black text-[#2D6A4F] uppercase tracking-wider">
                {isBm ? 'Pagi' : 'Morning'}
              </span>
              <p className="font-extrabold text-base text-[#1B4332] mt-0.5">
                {isBm ? 'Aina membuka SewSmart.' : 'Aina opens SewSmart on her phone.'}
              </p>
              <div className="inline-block mt-1.5 bg-[#FAF8F5] text-xs font-bold text-[#52796F] px-2.5 py-1 rounded-lg border border-[#E5DFD7]">
                💬 “{isBm ? 'Ada 2 peluang berdekatan.' : '2 opportunities nearby.'}”
              </div>
            </div>
          </div>

          <div className="text-center text-[#2D6A4F] font-black text-sm">↓</div>

          {/* Step 2: Tengah hari */}
          <div className="bg-white p-4.5 rounded-2xl border border-[#E5DFD7] flex items-start gap-4 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EC] text-lg flex items-center justify-center shrink-0">
              🕛
            </div>
            <div className="flex-1">
              <span className="text-xs font-black text-[#2D6A4F] uppercase tracking-wider">
                {isBm ? 'Tengah hari' : 'Midday'}
              </span>
              <p className="font-extrabold text-base text-[#1B4332] mt-0.5">
                {isBm ? 'Aina memilih:' : 'Aina selects:'}
              </p>
              <div className="mt-1.5 bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E5DFD7] text-xs font-bold text-[#1B4332] space-y-0.5">
                <div>• 20 kg Kain Kapas</div>
                <div>• 5 km dari rumah</div>
                <div className="text-[#2D6A4F]">• {isBm ? 'Anggaran RM35' : 'Est. RM35'}</div>
              </div>
            </div>
          </div>

          <div className="text-center text-[#2D6A4F] font-black text-sm">↓</div>

          {/* Step 3: Petang */}
          <div className="bg-white p-4.5 rounded-2xl border border-[#E5DFD7] flex items-start gap-4 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EC] text-lg flex items-center justify-center shrink-0">
              📦
            </div>
            <div className="flex-1">
              <span className="text-xs font-black text-[#2D6A4F] uppercase tracking-wider">
                {isBm ? 'Petang' : 'Afternoon'}
              </span>
              <p className="font-extrabold text-base text-[#1B4332] mt-0.5">
                {isBm ? 'Aina mengambil fabrik.' : 'Aina collects the fabric.'}
              </p>
              <div className="inline-block mt-1.5 bg-[#D8F3DC] text-xs font-extrabold text-[#2D6A4F] px-2.5 py-1 rounded-lg border border-[#2D6A4F]/20">
                ✓ “{isBm ? 'Koleksi selesai' : 'Collection completed'}”
              </div>
            </div>
          </div>

          <div className="text-center text-[#2D6A4F] font-black text-sm">↓</div>

          {/* Step 4: Selepas itu */}
          <div className="bg-white p-4.5 rounded-2xl border border-[#E5DFD7] flex items-start gap-4 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EC] text-lg flex items-center justify-center shrink-0">
              🧺
            </div>
            <div className="flex-1">
              <span className="text-xs font-black text-[#2D6A4F] uppercase tracking-wider">
                {isBm ? 'Selepas itu' : 'After that'}
              </span>
              <p className="font-extrabold text-base text-[#1B4332] mt-0.5">
                {isBm
                  ? 'Aina mengasingkan fabrik dan mengambil gambar.'
                  : 'Aina sorts the fabric and snaps a photo.'}
              </p>
            </div>
          </div>

          <div className="text-center text-[#2D6A4F] font-black text-sm">↓</div>

          {/* Step 5: Kemudian */}
          <div className="bg-white p-4.5 rounded-2xl border border-[#E5DFD7] flex items-start gap-4 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EC] text-lg flex items-center justify-center shrink-0">
              🎉
            </div>
            <div className="flex-1">
              <span className="text-xs font-black text-[#2D6A4F] uppercase tracking-wider">
                {isBm ? 'Kemudian' : 'Then'}
              </span>
              <p className="font-extrabold text-base text-[#1B4332] mt-0.5">
                {isBm ? 'Pembeli berminat.' : 'A buyer shows interest.'}
              </p>
              <div className="inline-block mt-1.5 bg-[#E8F0EC] text-xs font-bold text-[#2D6A4F] px-2.5 py-1 rounded-lg border border-[#2D6A4F]/20">
                “{isBm ? 'Ada pembeli untuk kain anda!' : 'Buyer matched for your fabric!'}”
              </div>
            </div>
          </div>

          <div className="text-center text-[#2D6A4F] font-black text-sm">↓</div>

          {/* Step 6: Akhirnya */}
          <div className="bg-[#2D6A4F] text-white p-5 rounded-2xl shadow-md text-center space-y-1">
            <span className="text-xs font-bold text-[#D8F3DC] uppercase tracking-wider block">
              {isBm ? 'Akhirnya' : 'Finally'}
            </span>
            <div className="text-2xl sm:text-3xl font-black">
              {isBm ? 'Aina menerima RM35' : 'Aina receives RM35'}
            </div>
            <p className="text-xs text-white/90">
              {isBm ? 'Masuk terus ke akaun bank beliau.' : 'Directly deposited into her account.'}
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 10. FAQ (SOALAN LAZIM) */}
      {/* ========================================================================= */}
      <section
        id="section-faq"
        className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs space-y-8"
      >
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-[#E8F0EC] px-3 py-1 rounded-full">
            {isBm ? 'Jawapan Mudah' : 'Common Questions'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? '“Soalan Lazim”' : '“Frequently Asked Questions”'}
          </h2>
          <p className="text-sm sm:text-base text-[#40534C]">
            {isBm ? 'Ketahui jawapan kepada soalan biasa.' : 'Quick answers to common questions.'}
          </p>
        </div>

        <div className="max-w-2xl mx-auto space-y-3">
          {faqs.map((item, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className="bg-[#FAF8F5] rounded-2xl border border-[#E5DFD7] overflow-hidden transition"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  className="w-full p-4.5 text-left font-extrabold text-base text-[#1B4332] flex items-center justify-between gap-4 cursor-pointer hover:bg-[#FAF8F5]/80 transition"
                  aria-expanded={isOpen}
                >
                  <span>{item.q}</span>
                  <div className="w-8 h-8 rounded-full bg-white border border-[#E5DFD7] flex items-center justify-center shrink-0 text-[#2D6A4F]">
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>
                {isOpen && (
                  <div className="px-4.5 pb-4.5 pt-1 text-sm sm:text-base text-[#40534C] font-medium leading-relaxed border-t border-[#E5DFD7]/60">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 11. HELP / SUPPORT */}
      {/* ========================================================================= */}
      <section
        id="section-help"
        className="bg-[#FAF8F5] rounded-3xl p-6 sm:p-10 border border-[#E5DFD7] shadow-xs text-center space-y-6"
      >
        <div className="space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F] bg-white px-3 py-1 rounded-full border border-[#E5DFD7]">
            {isBm ? 'Sentiasa Ada Sokongan' : 'Always Supported'}
          </span>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl text-[#1B4332]">
            {isBm ? '“Tak Pasti Nak Buat Apa?”' : '“Not Sure What To Do?”'}
          </h2>
          <p className="text-base sm:text-lg text-[#40534C] font-medium leading-relaxed">
            {isBm
              ? '“Jangan risau. SewSmart akan tunjukkan langkah seterusnya.”'
              : '“Don’t worry. SewSmart will guide you through the next step.”'}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-md mx-auto">
          {/* Large button: “❓ Perlukan Bantuan?” */}
          <button
            id="btn-help-perlukan-bantuan"
            type="button"
            onClick={onOpenHelpModal}
            className="w-full sm:w-auto flex-1 bg-white hover:bg-[#FAF8F5] text-[#1B4332] font-extrabold text-base py-4 px-6 rounded-2xl border-2 border-[#2D6A4F] transition flex items-center justify-center gap-2 touch-target cursor-pointer shadow-xs"
          >
            <HelpCircle className="w-5 h-5 text-[#2D6A4F]" />
            <span>{isBm ? '❓ Perlukan Bantuan?' : '❓ Need Help?'}</span>
          </button>

          {/* “Hubungi SewSmart” */}
          <button
            id="btn-help-hubungi-sewsmart"
            type="button"
            onClick={() => setIsContactModalOpen(true)}
            className="w-full sm:w-auto flex-1 bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-base py-4 px-6 rounded-2xl transition flex items-center justify-center gap-2 touch-target cursor-pointer shadow-xs"
          >
            <MessageCircle className="w-5 h-5" />
            <span>{isBm ? 'Hubungi SewSmart' : 'Contact SewSmart'}</span>
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 12. FINAL CTA */}
      {/* ========================================================================= */}
      <section
        id="section-final-cta"
        className="bg-[#2D6A4F] text-white rounded-3xl p-8 sm:p-12 shadow-lg text-center space-y-6"
      >
        <div className="space-y-3 max-w-2xl mx-auto">
          <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white tracking-tight">
            {isBm ? '“Sedia Untuk Mula?”' : '“Ready To Start?”'}
          </h2>
          <p className="text-base sm:text-xl text-[#D8F3DC] font-medium leading-relaxed">
            {isBm
              ? '“Daftar secara percuma dan cari peluang fabrik pertama anda.”'
              : '“Register for free and discover your very first fabric opportunity.”'}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-md mx-auto pt-2">
          {/* Primary: “Mula Sekarang” */}
          <button
            id="btn-final-mula-sekarang"
            type="button"
            onClick={() => setIsRegistrationOpen(true)}
            className="w-full sm:w-auto flex-1 bg-white hover:bg-[#FAF8F5] text-[#1B4332] font-black text-lg py-4 px-8 rounded-2xl shadow-md transition flex items-center justify-center gap-2 touch-target cursor-pointer"
          >
            <span>{isBm ? 'Mula Sekarang' : 'Start Now'}</span>
            <ArrowRight className="w-5 h-5 text-[#1B4332]" />
          </button>

          {/* Secondary: “Saya Ada Sisa Fabrik” */}
          <button
            id="btn-final-saya-ada-sisa"
            type="button"
            onClick={onGoToSupplier}
            className="w-full sm:w-auto flex-1 bg-white/15 hover:bg-white/20 text-white font-bold text-base py-4 px-6 rounded-2xl border border-white/30 transition touch-target cursor-pointer"
          >
            {isBm ? 'Saya Ada Sisa Fabrik' : 'I Have Fabric Waste'}
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* INTERACTIVE REGISTRATION MODAL */}
      {/* ========================================================================= */}
      <RegistrationModal
        isOpen={isRegistrationOpen}
        onClose={() => setIsRegistrationOpen(false)}
        language={language}
        onCompleteToCollector={(tab) => {
          onGoToCollector(tab || 'peluang');
        }}
        onGoToSupplier={onGoToSupplier}
        onGoToBuyer={onGoToBuyer}
        onViewHowItWorks={() => {
          setIsRegistrationOpen(false);
          handleScrollToHowItWorks();
        }}
      />

      {/* ========================================================================= */}
      {/* CONTACT SEWSMART POPUP / MODAL */}
      {/* ========================================================================= */}
      {isContactModalOpen && (
        <div
          id="contact-modal-backdrop"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setIsContactModalOpen(false)}
        >
          <div
            id="contact-modal-card"
            className="bg-[#FAF8F5] w-full max-w-md rounded-3xl p-6 sm:p-8 shadow-2xl border border-[#E5DFD7] space-y-6 text-[#1E2923] relative animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#2D6A4F]">
                <MessageCircle className="w-6 h-6" />
                <h3 className="font-display font-extrabold text-xl text-[#1B4332]">
                  {isBm ? 'Hubungi SewSmart' : 'Contact SewSmart'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsContactModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white border border-[#E5DFD7] flex items-center justify-center text-[#1E2923]/70 hover:text-[#1E2923]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-[#40534C] leading-relaxed">
              {isBm
                ? 'Pasukan SewSmart sedia membantu anda bila-bila masa. Anda boleh hubungi kami melalui WhatsApp atau talian mesra komuniti.'
                : 'The SewSmart team is ready to guide you. Reach out to us via WhatsApp or community hotline.'}
            </p>

            <div className="space-y-3 text-sm">
              <a
                href="https://wa.me/60123456789"
                target="_blank"
                rel="noreferrer"
                className="bg-[#D8F3DC] hover:bg-[#C2EAC7] text-[#1B4332] p-4 rounded-2xl border border-[#2D6A4F]/20 flex items-center justify-between font-bold transition block"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-xl">
                    💬
                  </div>
                  <div>
                    <span className="block font-extrabold">WhatsApp SewSmart</span>
                    <span className="text-xs text-[#52796F]">012-345 6789 (Bantuan Segera)</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-[#2D6A4F]" />
              </a>

              <div className="bg-white p-4 rounded-2xl border border-[#E5DFD7] flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FAF8F5] border border-[#E5DFD7] flex items-center justify-center text-xl">
                  📞
                </div>
                <div>
                  <span className="block font-extrabold text-[#1B4332]">Talian Mesra Bebas Tol</span>
                  <span className="text-xs text-[#52796F]">1-800-88-SEW (9 pagi – 6 petang)</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsContactModalOpen(false)}
              className="w-full bg-[#2D6A4F] text-white font-bold text-base py-3.5 rounded-xl shadow-xs"
            >
              {isBm ? 'Faham & Tutup' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
