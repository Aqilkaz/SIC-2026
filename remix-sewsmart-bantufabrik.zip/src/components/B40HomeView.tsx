import React from 'react';
import { Opportunity, ActiveCollection, AppLanguage } from '../types';
import { ArrowRight, ChevronRight, CheckCircle2, Sparkles } from 'lucide-react';

interface B40HomeViewProps {
  language: AppLanguage;
  opportunities: Opportunity[];
  activeCollection: ActiveCollection | null;
  onSelectOpportunity: (opp: Opportunity) => void;
  onGoToOpportunities: () => void;
  onOpenGoal: () => void;
  onOpenSorting: () => void;
  onOpenBuyerNotification: () => void;
  onOpenPaymentNotification: () => void;
}

export const B40HomeView: React.FC<B40HomeViewProps> = ({
  language,
  opportunities,
  activeCollection,
  onSelectOpportunity,
  onGoToOpportunities,
  onOpenGoal,
  onOpenSorting,
  onOpenBuyerNotification,
  onOpenPaymentNotification
}) => {
  const isBm = language === 'bm';
  const nearbySlice = opportunities.slice(0, 2);

  // Status styling for collection
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'belum_diambil':
        return {
          color: 'bg-amber-100 text-amber-900 border-amber-300',
          dot: 'bg-amber-500',
          text: isBm ? '🟡 Belum diambil' : '🟡 Not collected yet'
        };
      case 'sudah_diambil':
      case 'diasingkan':
      case 'disenaraikan':
        return {
          color: 'bg-blue-100 text-blue-900 border-blue-300',
          dot: 'bg-blue-600',
          text: isBm ? '🔵 Sudah diambil' : '🔵 Collected'
        };
      case 'ada_pembeli':
        return {
          color: 'bg-purple-100 text-purple-900 border-purple-300',
          dot: 'bg-purple-600',
          text: isBm ? '🟣 Ada Pembeli!' : '🟣 Buyer Matched!'
        };
      case 'sudah_dijual':
      case 'selesai':
      default:
        return {
          color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
          dot: 'bg-emerald-600',
          text: isBm ? '🟢 Sudah dijual' : '🟢 Sold'
        };
    }
  };

  const currentStatusInfo = activeCollection ? getStatusBadge(activeCollection.status) : null;

  return (
    <div className="space-y-5 pb-6">
      {/* 1. Header */}
      <div className="pt-2">
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-[#2b5b4b] tracking-tight">
          {isBm ? 'Selamat pagi, Aina 👋' : 'Good morning, Aina 👋'}
        </h1>
        <p className="text-base text-[#315f4f] mt-1 font-medium">
          {isBm
            ? 'Mari cari peluang untuk tambah pendapatan hari ini.'
            : 'Let’s find opportunities to boost your income today.'}
        </p>
      </div>

      {/* 2. Main Card: Sasaran Bulan Ini (Containers #f8f4ee) */}
      <div 
        onClick={onOpenGoal}
        className="bg-[#f8f4ee] rounded-3xl p-5 sm:p-6 shadow-sm border-2 border-[#23755c]/20 hover:border-[#2b5b4b] transition cursor-pointer relative overflow-hidden group"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#2b5b4b]"></span>
            <h2 className="font-display font-bold text-lg text-[#2b5b4b]">
              {isBm ? 'Sasaran Bulan Ini' : 'This Month’s Goal'}
            </h2>
          </div>
          <span className="text-xs font-bold text-[#2b5b4b] bg-white px-2.5 py-1 rounded-full border border-[#23755c]/20">
            {isBm ? 'Sentuh untuk perincian' : 'Tap for details'}
          </span>
        </div>

        {/* Large Goal Amount */}
        <div className="mt-3 flex items-baseline gap-2">
          <span className="font-display text-3xl sm:text-4xl font-extrabold text-[#2b5b4b] tracking-tight">
            RM62
          </span>
          <span className="text-xl font-bold text-[#315f4f]/60">
            / RM100
          </span>
        </div>

        <p className="text-sm font-bold text-[#23755c] mt-1">
          {isBm ? 'RM38 lagi untuk capai sasaran' : 'RM38 more to reach your goal'}
        </p>

        {/* Visual Progress Bar */}
        <div className="mt-3.5 w-full bg-white rounded-full h-3.5 overflow-hidden p-0.5 border border-[#e8dfd5]">
          <div
            className="bg-[#60a103] h-full rounded-full transition-all duration-500"
            style={{ width: '62%' }}
          ></div>
        </div>

        {/* Large Button: Cari Peluang (Buttons #60a103) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onGoToOpportunities();
          }}
          className="mt-5 w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-3.5 px-5 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
        >
          <span>{isBm ? 'Cari Peluang' : 'Find Opportunities'}</span>
          <ArrowRight className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* 3. Koleksi Saya (Container #f8f4ee) */}
      {activeCollection && (
        <div className="bg-[#f8f4ee] rounded-3xl p-5 sm:p-6 shadow-sm border border-[#e8dfd5] space-y-4">
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-xs font-bold text-[#315f4f] uppercase tracking-wider">
                {isBm ? 'Koleksi Saya' : 'My Collection'}
              </span>
              <h3 className="font-display font-extrabold text-xl text-[#2b5b4b] mt-0.5">
                {activeCollection.fabricType} · {activeCollection.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'}
              </h3>
            </div>
            <span className={`text-xs font-bold px-3 py-1 rounded-full border ${currentStatusInfo?.color}`}>
              {currentStatusInfo?.text}
            </span>
          </div>

          {/* Simple 6-step progress timeline */}
          <div className="pt-2 pb-1">
            <p className="text-xs font-bold text-[#315f4f] mb-2 uppercase tracking-wide">
              {isBm ? 'Perjalanan Fabrik Anda:' : 'Your Fabric Journey:'}
            </p>
            <div className="grid grid-cols-6 gap-1 text-center">
              {[
                { step: 1, label: isBm ? 'Diterima' : 'Accepted' },
                { step: 2, label: isBm ? 'Diambil' : 'Collected' },
                { step: 3, label: isBm ? 'Diasing' : 'Sorted' },
                { step: 4, label: isBm ? 'Disenarai' : 'Listed' },
                { step: 5, label: isBm ? 'Dijual' : 'Sold' },
                { step: 6, label: isBm ? 'Dibayar' : 'Paid' },
              ].map((item) => {
                const isCompleted = activeCollection.currentStep > item.step;
                const isCurrent = activeCollection.currentStep === item.step;

                return (
                  <div key={item.step} className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold transition ${
                        isCompleted
                          ? 'bg-[#2b5b4b] text-white'
                          : isCurrent
                          ? 'bg-[#60a103] text-white ring-4 ring-lime-100 shadow-sm'
                          : 'bg-white text-[#315f4f]/50 border border-[#e8dfd5]'
                      }`}
                    >
                      {isCompleted ? '✓' : item.step}
                    </div>
                    <span
                      className={`text-[10px] mt-1 line-clamp-1 leading-tight ${
                        isCurrent
                          ? 'font-extrabold text-[#23755c]'
                          : isCompleted
                          ? 'font-bold text-[#2b5b4b]'
                          : 'text-[#315f4f]/50'
                      }`}
                    >
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Step guidance box with clear single next action */}
          <div className="bg-white rounded-2xl p-4 border border-[#e8dfd5] space-y-3">
            <div>
              <span className="text-xs font-bold text-[#23755c] uppercase tracking-wider block">
                {isBm ? 'Langkah anda sekarang:' : 'Your current step:'}
              </span>
              <h4 className="font-display font-extrabold text-lg text-[#2b5b4b] mt-0.5">
                {activeCollection.currentStep === 1 && (isBm ? 'Ambil kain di lokasi' : 'Pick up fabric at location')}
                {activeCollection.currentStep === 2 && (isBm ? 'Bawa pulang kain' : 'Bring fabric home')}
                {activeCollection.currentStep === 3 && (isBm ? 'Asingkan kain' : 'Sort the fabric')}
                {activeCollection.currentStep === 4 && (isBm ? 'Kain sedang disenaraikan' : 'Fabric is listed')}
                {activeCollection.currentStep === 5 && (isBm ? 'Ada pembeli berminat!' : 'A buyer is interested!')}
                {activeCollection.currentStep === 6 && (isBm ? 'Bayaran sedia diterima' : 'Payment ready to collect')}
              </h4>
              <p className="text-sm text-[#315f4f] mt-1 font-medium">
                {activeCollection.currentStep === 3 &&
                  (isBm
                    ? 'Asingkan kain mengikut jenis dan keadaan sebelum anda senaraikan.'
                    : 'Sort fabric by material and condition before listing.')}
                {activeCollection.currentStep === 4 &&
                  (isBm
                    ? 'Kain anda sedia menunggu padanan pembeli kraf.'
                    : 'Your fabric is live, awaiting craft buyers.')}
                {activeCollection.currentStep === 5 &&
                  (isBm
                    ? 'EcoCraft Malaysia sedia membeli kain kapas anda.'
                    : 'EcoCraft Malaysia is ready to buy your cotton fabric.')}
                {activeCollection.currentStep === 6 &&
                  (isBm
                    ? 'Bayaran RM18 telah disahkan untuk tugasan ini.'
                    : 'Payment of RM18 is verified for this job.')}
              </p>
            </div>

            {/* Action button strictly matching the current step (Buttons #60a103) */}
            {activeCollection.currentStep === 3 && (
              <button
                type="button"
                onClick={onOpenSorting}
                className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
              >
                <span>{isBm ? 'Asingkan Kain' : 'Sort Fabric'}</span>
                <ArrowRight className="w-5 h-5 text-white" />
              </button>
            )}

            {activeCollection.currentStep === 4 && (
              <button
                type="button"
                onClick={onOpenBuyerNotification}
                className="w-full bg-[#23755c] hover:bg-[#2b5b4b] text-white font-extrabold text-base py-3 px-4 rounded-xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
              >
                <Sparkles className="w-4 h-4 text-[#f8f4ee]" />
                <span>{isBm ? 'Simulasi Ada Pembeli' : 'Simulate Buyer Match'}</span>
              </button>
            )}

            {activeCollection.currentStep === 5 && (
              <button
                type="button"
                onClick={onOpenBuyerNotification}
                className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
              >
                <span>{isBm ? 'Lihat Pesanan Pembeli (RM18)' : 'View Buyer Order (RM18)'}</span>
                <ArrowRight className="w-5 h-5 text-white" />
              </button>
            )}

            {activeCollection.currentStep === 6 && (
              <button
                type="button"
                onClick={onOpenPaymentNotification}
                className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
              >
                <span>{isBm ? 'Lihat Bayaran Diterima' : 'View Received Payment'}</span>
                <CheckCircle2 className="w-5 h-5 text-white" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* 4. Peluang Berdekatan (Containers #f8f4ee) */}
      <div className="space-y-3 pt-1">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-extrabold text-xl text-[#2b5b4b]">
            {isBm ? 'Peluang Berdekatan' : 'Nearby Opportunities'}
          </h2>
          <span className="text-xs font-bold text-[#2b5b4b] bg-[#f8f4ee] px-2.5 py-1 rounded-full border border-[#23755c]/20">
            {opportunities.length} {isBm ? 'Tersedia' : 'Available'}
          </span>
        </div>

        <div className="space-y-3">
          {nearbySlice.map((opp) => (
            <div
              key={opp.id}
              className="bg-[#f8f4ee] rounded-3xl p-5 shadow-sm border border-[#e8dfd5] hover:border-[#2b5b4b] transition space-y-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                    {opp.title}
                  </h3>
                  <p className="text-sm text-[#315f4f] font-medium mt-0.5">
                    {opp.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'} · {opp.distanceKm} km {isBm ? 'dari anda' : 'from you'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#315f4f]/70 block font-medium">
                    {isBm ? 'Anggaran pendapatan:' : 'Est. earnings:'}
                  </span>
                  <span className="font-display text-2xl font-extrabold text-[#2b5b4b] block">
                    RM{opp.estEarnings}
                  </span>
                </div>
              </div>

              {/* Large button: Lihat Peluang (Buttons #60a103) */}
              <button
                type="button"
                onClick={() => onSelectOpportunity(opp)}
                className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3 px-4 rounded-2xl transition flex items-center justify-center gap-2 touch-target shadow-xs"
              >
                <span>{isBm ? 'Lihat Peluang' : 'View Opportunity'}</span>
                <ChevronRight className="w-5 h-5 text-white" />
              </button>
            </div>
          ))}
        </div>

        {/* Bottom Button: Lihat Semua Peluang */}
        <button
          type="button"
          onClick={onGoToOpportunities}
          className="w-full py-3.5 text-center text-sm font-extrabold text-[#2b5b4b] hover:bg-[#f8f4ee] rounded-2xl transition border border-[#23755c]/30 touch-target"
        >
          {isBm ? 'Lihat Semua Peluang' : 'View All Opportunities'} →
        </button>
      </div>
    </div>
  );
};
