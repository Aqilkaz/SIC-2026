import React, { useState } from 'react';
import { AppLanguage } from '../types';
import { X, Check, ArrowRight, User, Phone, MapPin, Sparkles, Building2, ShoppingBag } from 'lucide-react';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onCompleteToCollector: (tab?: 'utama' | 'peluang') => void;
  onGoToSupplier: () => void;
  onGoToBuyer: () => void;
  onViewHowItWorks: () => void;
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  isOpen,
  onClose,
  language,
  onCompleteToCollector,
  onGoToSupplier,
  onGoToBuyer,
  onViewHowItWorks
}) => {
  const isBm = language === 'bm';
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedRole, setSelectedRole] = useState<'collector' | 'supplier' | 'buyer'>('collector');
  const [name, setName] = useState('Aina');
  const [phone, setPhone] = useState('012-3456789');
  const [area, setArea] = useState('Selangor');

  if (!isOpen) return null;

  const handleReset = () => {
    setStep(1);
    setSelectedRole('collector');
    onClose();
  };

  return (
    <div
      id="registration-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={handleReset}
    >
      <div
        id="registration-modal-card"
        className="bg-[#FAF8F5] w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-[#E5DFD7] text-[#1E2923] relative animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="btn-close-registration"
          onClick={handleReset}
          className="absolute top-5 right-5 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-[#1E2923]/70 hover:text-[#1E2923] flex items-center justify-center border border-[#E5DFD7] transition"
          aria-label="Tutup"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Step Indicator */}
        <div className="flex items-center gap-2 mb-6">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-2 flex-1 rounded-full transition-all duration-300 ${
                s === step
                  ? 'bg-[#2D6A4F]'
                  : s < step
                  ? 'bg-[#52B788]'
                  : 'bg-[#E5DFD7]'
              }`}
            />
          ))}
        </div>

        {/* ========================================================================= */}
        {/* SCREEN 1: Welcome Screen */}
        {/* ========================================================================= */}
        {step === 1 && (
          <div className="space-y-6 text-center py-2">
            <div className="w-16 h-16 rounded-2xl bg-[#E8F0EC] text-[#2D6A4F] flex items-center justify-center mx-auto text-3xl shadow-xs">
              👋
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1B4332] tracking-tight">
                {isBm ? 'Selamat Datang ke SewSmart 👋' : 'Welcome to SewSmart 👋'}
              </h2>
              <p className="text-base text-[#40534C] max-w-sm mx-auto leading-relaxed">
                {isBm
                  ? 'Mari buat akaun. Hanya beberapa langkah.'
                  : 'Let’s create your account. Just a few easy steps.'}
              </p>
            </div>

            {/* Simple Value Pill */}
            <div className="bg-white p-4 rounded-2xl border border-[#E5DFD7] text-left space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-sm font-bold text-[#2D6A4F]">
                <Check className="w-4 h-4 text-[#2D6A4F] shrink-0" />
                <span>{isBm ? 'Pendaftaran 100% Percuma' : '100% Free Registration'}</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm font-bold text-[#2D6A4F]">
                <Check className="w-4 h-4 text-[#2D6A4F] shrink-0" />
                <span>{isBm ? 'Tanpa Modal & Tanpa Jahit' : 'Zero Capital & No Sewing Needed'}</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm font-bold text-[#2D6A4F]">
                <Check className="w-4 h-4 text-[#2D6A4F] shrink-0" />
                <span>{isBm ? 'Terus Boleh Cari Peluang' : 'Instantly Find Nearby Opportunities'}</span>
              </div>
            </div>

            <button
              id="btn-reg-screen1-mula"
              type="button"
              onClick={() => setStep(2)}
              className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-lg py-4 px-6 rounded-2xl shadow-md transition flex items-center justify-center gap-2 touch-target cursor-pointer"
            >
              <span>{isBm ? 'Mula' : 'Get Started'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SCREEN 2: Role Selection */}
        {/* ========================================================================= */}
        {step === 2 && (
          <div className="space-y-6 py-2">
            <div className="text-center space-y-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F]">
                {isBm ? 'Langkah 2 daripada 4' : 'Step 2 of 4'}
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1B4332] tracking-tight">
                {isBm ? 'Apa Yang Anda Mahu Lakukan?' : 'What Would You Like To Do?'}
              </h2>
              <p className="text-sm text-[#40534C]">
                {isBm ? 'Pilih peranan yang paling sesuai untuk anda.' : 'Choose the role that fits you best.'}
              </p>
            </div>

            <div className="space-y-3">
              {/* Option 1: Collector (Main) */}
              <button
                id="btn-role-collector"
                type="button"
                onClick={() => setSelectedRole('collector')}
                className={`w-full text-left p-4.5 rounded-2xl border-2 transition relative flex items-start gap-4 cursor-pointer ${
                  selectedRole === 'collector'
                    ? 'bg-[#E8F0EC] border-[#2D6A4F] shadow-sm'
                    : 'bg-white border-[#E5DFD7] hover:border-[#2D6A4F]/40'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-white border border-[#2D6A4F]/20 flex items-center justify-center text-2xl shrink-0">
                  👩
                </div>
                <div className="flex-1 min-w-0 pr-6">
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-base text-[#1B4332]">
                      {isBm ? 'Saya Mahu Jana Pendapatan' : 'I Want To Earn Income'}
                    </h3>
                    <span className="bg-[#2D6A4F] text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                      {isBm ? 'Disyorkan' : 'Popular'}
                    </span>
                  </div>
                  <p className="text-xs text-[#40534C] mt-1 leading-relaxed">
                    {isBm ? 'Kumpul dan asingkan fabrik untuk dapat bayaran.' : 'Collect and sort fabrics to earn money.'}
                  </p>
                </div>
                {selectedRole === 'collector' && (
                  <div className="absolute right-4 top-5 w-6 h-6 rounded-full bg-[#2D6A4F] text-white flex items-center justify-center">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </button>

              {/* Option 2: Supplier */}
              <button
                id="btn-role-supplier"
                type="button"
                onClick={() => setSelectedRole('supplier')}
                className={`w-full text-left p-4.5 rounded-2xl border-2 transition relative flex items-start gap-4 cursor-pointer ${
                  selectedRole === 'supplier'
                    ? 'bg-[#E8F0EC] border-[#2D6A4F] shadow-sm'
                    : 'bg-white border-[#E5DFD7] hover:border-[#2D6A4F]/40'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-white border border-[#E5DFD7] flex items-center justify-center text-2xl shrink-0">
                  🏭
                </div>
                <div className="flex-1 min-w-0 pr-6">
                  <h3 className="font-extrabold text-base text-[#1B4332]">
                    {isBm ? 'Saya Ada Sisa Fabrik' : 'I Have Fabric Waste'}
                  </h3>
                  <p className="text-xs text-[#40534C] mt-1 leading-relaxed">
                    {isBm ? 'Untuk kilang, hotel dan perniagaan.' : 'For factories, hotels, and businesses.'}
                  </p>
                </div>
                {selectedRole === 'supplier' && (
                  <div className="absolute right-4 top-5 w-6 h-6 rounded-full bg-[#2D6A4F] text-white flex items-center justify-center">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </button>

              {/* Option 3: Buyer */}
              <button
                id="btn-role-buyer"
                type="button"
                onClick={() => setSelectedRole('buyer')}
                className={`w-full text-left p-4.5 rounded-2xl border-2 transition relative flex items-start gap-4 cursor-pointer ${
                  selectedRole === 'buyer'
                    ? 'bg-[#E8F0EC] border-[#2D6A4F] shadow-sm'
                    : 'bg-white border-[#E5DFD7] hover:border-[#2D6A4F]/40'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-white border border-[#E5DFD7] flex items-center justify-center text-2xl shrink-0">
                  🛍️
                </div>
                <div className="flex-1 min-w-0 pr-6">
                  <h3 className="font-extrabold text-base text-[#1B4332]">
                    {isBm ? 'Saya Mahu Beli Fabrik' : 'I Want To Buy Fabric'}
                  </h3>
                  <p className="text-xs text-[#40534C] mt-1 leading-relaxed">
                    {isBm ? 'Cari dan beli bahan untuk kraf & upcycle.' : 'Source and buy sorted fabrics for craft & upcycle.'}
                  </p>
                </div>
                {selectedRole === 'buyer' && (
                  <div className="absolute right-4 top-5 w-6 h-6 rounded-full bg-[#2D6A4F] text-white flex items-center justify-center">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </button>
            </div>

            {/* Selected feedback */}
            {selectedRole === 'collector' && (
              <div className="bg-[#E8F0EC] p-3.5 rounded-xl border border-[#2D6A4F]/20 flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[#2D6A4F] shrink-0 mt-0.5" />
                <div className="text-xs text-[#1B4332] leading-relaxed">
                  <span className="font-bold">{isBm ? 'Pilihan anda: Jana Pendapatan. ' : 'Your choice: Earn Income. '}</span>
                  {isBm
                    ? 'Kami akan tunjukkan peluang fabrik berdekatan anda.'
                    : 'We will show fabric opportunities near your location.'}
                </div>
              </div>
            )}

            <button
              id="btn-reg-screen2-teruskan"
              type="button"
              onClick={() => {
                if (selectedRole === 'supplier') {
                  onClose();
                  onGoToSupplier();
                } else if (selectedRole === 'buyer') {
                  onClose();
                  onGoToBuyer();
                } else {
                  setStep(3);
                }
              }}
              className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-lg py-4 px-6 rounded-2xl shadow-md transition flex items-center justify-center gap-2 touch-target cursor-pointer"
            >
              <span>{isBm ? 'Teruskan' : 'Continue'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SCREEN 3: Simple Essential Form */}
        {/* ========================================================================= */}
        {step === 3 && (
          <div className="space-y-5 py-2">
            <div className="text-center space-y-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-[#2D6A4F]">
                {isBm ? 'Langkah 3 daripada 4' : 'Step 3 of 4'}
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1B4332] tracking-tight">
                {isBm ? 'Buat Akaun Anda' : 'Create Your Account'}
              </h2>
              <p className="text-sm text-[#40534C]">
                {isBm ? 'Hanya maklumat asas yang penting.' : 'Only essential basic information.'}
              </p>
            </div>

            <div className="space-y-4">
              {/* Name */}
              <div>
                <label className="block text-sm font-bold text-[#1B4332] mb-1.5 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-[#2D6A4F]" />
                  <span>{isBm ? 'Nama' : 'Full Name'}</span>
                </label>
                <input
                  id="reg-input-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Aina binti Ismail"
                  className="w-full bg-white border-2 border-[#E5DFD7] focus:border-[#2D6A4F] rounded-xl px-4 py-3 text-base text-[#1E2923] font-medium outline-hidden transition"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-bold text-[#1B4332] mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-4 h-4 text-[#2D6A4F]" />
                  <span>{isBm ? 'Nombor Telefon' : 'Phone Number'}</span>
                </label>
                <input
                  id="reg-input-phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01X-XXXXXXX"
                  className="w-full bg-white border-2 border-[#E5DFD7] focus:border-[#2D6A4F] rounded-xl px-4 py-3 text-base text-[#1E2923] font-medium outline-hidden transition"
                />
              </div>

              {/* Area */}
              <div>
                <label className="block text-sm font-bold text-[#1B4332] mb-1.5 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#2D6A4F]" />
                  <span>{isBm ? 'Kawasan' : 'Area / State'}</span>
                </label>
                <select
                  id="reg-select-area"
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  className="w-full bg-white border-2 border-[#E5DFD7] focus:border-[#2D6A4F] rounded-xl px-4 py-3 text-base text-[#1E2923] font-medium outline-hidden transition cursor-pointer"
                >
                  <option value="Selangor">Selangor (Shah Alam, Klang, Petaling Jaya)</option>
                  <option value="Kuala Lumpur">Kuala Lumpur</option>
                  <option value="Johor">Johor (Johor Bahru, Batu Pahat)</option>
                  <option value="Pulau Pinang">Pulau Pinang</option>
                  <option value="Perak">Perak (Ipoh)</option>
                  <option value="Negeri Sembilan">Negeri Sembilan (Seremban)</option>
                </select>
              </div>
            </div>

            <div className="bg-[#E8F0EC] p-3 rounded-xl border border-[#2D6A4F]/20 text-xs text-[#2D6A4F] font-medium text-center">
              🔒 {isBm ? 'Maklumat anda selamat. Tiada bayaran pendahuluan diperlukan.' : 'Your details are safe. No upfront payment required.'}
            </div>

            <button
              id="btn-reg-screen3-buat-akaun"
              type="button"
              onClick={() => setStep(4)}
              className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-lg py-4 px-6 rounded-2xl shadow-md transition flex items-center justify-center gap-2 touch-target cursor-pointer"
            >
              <span>{isBm ? 'Buat Akaun' : 'Create Account'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SCREEN 4: Success & Direct Start */}
        {/* ========================================================================= */}
        {step === 4 && (
          <div className="space-y-6 text-center py-2">
            <div className="w-20 h-20 rounded-full bg-[#D8F3DC] text-[#2D6A4F] flex items-center justify-center mx-auto shadow-xs">
              <Check className="w-10 h-10 stroke-[3]" />
            </div>

            <div className="space-y-2">
              <span className="inline-block bg-[#D8F3DC] text-[#2D6A4F] text-xs font-extrabold px-3 py-1 rounded-full">
                ✓ {isBm ? 'Akaun Berjaya Dibuat!' : 'Account Successfully Created!'}
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1B4332] tracking-tight">
                {isBm ? 'Akaun Anda Siap! 🎉' : 'Your Account is Ready! 🎉'}
              </h2>
              <p className="text-base text-[#40534C] max-w-sm mx-auto leading-relaxed">
                {isBm
                  ? `Tahniah ${name}! Jom mula mencari peluang fabrik berdekatan anda.`
                  : `Congratulations ${name}! Let's start finding fabric opportunities near you.`}
              </p>
            </div>

            {/* Opportunity Quick Preview */}
            <div className="bg-white p-4 rounded-2xl border border-[#E5DFD7] text-left space-y-2 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#52796F] font-bold">
                <span>{isBm ? 'Peluang Terdekat Untuk Anda' : 'Nearest Opportunity For You'}</span>
                <span className="bg-[#E8F0EC] text-[#2D6A4F] px-2 py-0.5 rounded-full">5 km</span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-[#1B4332] text-base">Kain Kapas (20 kg)</h4>
                  <p className="text-xs text-[#52796F]">Hotel Seri Malaysia · Shah Alam</p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#52796F] block">{isBm ? 'Anggaran' : 'Estimated'}</span>
                  <span className="text-lg font-black text-[#2D6A4F]">RM35</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <button
                id="btn-reg-screen4-cari-peluang"
                type="button"
                onClick={() => {
                  onClose();
                  onCompleteToCollector('peluang');
                }}
                className="w-full bg-[#2D6A4F] hover:bg-[#235341] text-white font-bold text-lg py-4 px-6 rounded-2xl shadow-md transition flex items-center justify-center gap-2 touch-target cursor-pointer"
              >
                <span>{isBm ? 'Cari Peluang' : 'Find Opportunities'}</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                id="btn-reg-screen4-lihat-cara"
                type="button"
                onClick={() => {
                  onClose();
                  onViewHowItWorks();
                }}
                className="w-full bg-white hover:bg-[#FAF8F5] text-[#2D6A4F] font-bold text-base py-3.5 px-6 rounded-2xl border border-[#2D6A4F]/30 transition touch-target cursor-pointer"
              >
                {isBm ? 'Lihat Cara SewSmart Berfungsi' : 'See How SewSmart Works'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
