import React from 'react';
import { B40Tab, AppLanguage } from '../types';
import { Home, MapPin, Wallet, User } from 'lucide-react';

interface BottomNavProps {
  activeTab: B40Tab;
  setActiveTab: (tab: B40Tab) => void;
  language: AppLanguage;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  language
}) => {
  const navItems: { id: B40Tab; labelBm: string; labelEn: string; icon: React.ReactNode }[] = [
    {
      id: 'utama',
      labelBm: 'Utama',
      labelEn: 'Home',
      icon: <Home className="w-5 h-5" />
    },
    {
      id: 'peluang',
      labelBm: 'Peluang',
      labelEn: 'Opportunities',
      icon: <MapPin className="w-5 h-5" />
    },
    {
      id: 'pendapatan',
      labelBm: 'Pendapatan',
      labelEn: 'Earnings',
      icon: <Wallet className="w-5 h-5" />
    },
    {
      id: 'profil',
      labelBm: 'Profil',
      labelEn: 'Profile',
      icon: <User className="w-5 h-5" />
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#ffffff] border-t border-[#e8dfd5] shadow-lg pb-safe">
      <div className="max-w-xl mx-auto px-2 flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex-1 py-2.5 px-1 flex flex-col items-center justify-center gap-1 transition touch-target ${
                isActive
                  ? 'text-[#2b5b4b] font-extrabold'
                  : 'text-[#315f4f]/70 hover:text-[#2b5b4b] font-semibold'
              }`}
            >
              <div
                className={`p-1.5 rounded-xl transition ${
                  isActive ? 'bg-[#f8f4ee] text-[#2b5b4b] shadow-2xs' : ''
                }`}
              >
                {item.icon}
              </div>
              <span className={`text-[12px] leading-none ${isActive ? 'font-extrabold text-[#2b5b4b]' : 'text-[#315f4f]/70'}`}>
                {language === 'bm' ? item.labelBm : item.labelEn}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
