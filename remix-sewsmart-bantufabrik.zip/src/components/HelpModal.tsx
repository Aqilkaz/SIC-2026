import React from 'react';
import { AppLanguage } from '../types';
import { Phone, MessageSquare, X } from 'lucide-react';

interface HelpModalProps {
  language: AppLanguage;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ language, onClose }) => {
  const isBm = language === 'bm';

  const steps = [
    { num: 1, text: isBm ? 'Cari peluang' : 'Find opportunities', desc: isBm ? 'Pilih sisa kain berdekatan rumah anda.' : 'Pick nearby textile scrap opportunities.' },
    { num: 2, text: isBm ? 'Ambil kain' : 'Pick up fabric', desc: isBm ? 'Pergi ke lokasi pembekal mengikut tarikh.' : 'Go to the supplier location on schedule.' },
    { num: 3, text: isBm ? 'Asingkan kain' : 'Sort fabric', desc: isBm ? 'Asingkan mengikut jenis & keadaan kain.' : 'Sort by material type and condition.' },
    { num: 4, text: isBm ? 'Senaraikan kain' : 'List fabric', desc: isBm ? 'Ambil gambar dan sahkan senarai dengan mudah.' : 'Snap a photo and confirm the simple listing.' },
    { num: 5, text: isBm ? 'Tunggu pembeli' : 'Wait for buyer', desc: isBm ? 'SewSmart padankan pembeli tanpa perlu tawar-menawar.' : 'SewSmart auto-matches buyers without negotiation.' },
    { num: 6, text: isBm ? 'Terima bayaran' : 'Receive payment', desc: isBm ? 'Wang terus masuk ke dompet anda.' : 'Money goes directly into your earnings wallet.' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] my-auto space-y-6">
        <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">❓</span>
            <h2 className="font-display font-extrabold text-xl text-[#2b5b4b]">
              {isBm ? 'Perlukan bantuan?' : 'Need help?'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-[#f8f4ee] touch-target"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 6-step simple guidance */}
        <div className="space-y-3">
          <h3 className="font-bold text-base text-[#2b5b4b]">
            {isBm ? 'Cara menggunakan SewSmart' : 'How to use SewSmart'}
          </h3>

          <div className="space-y-2.5">
            {steps.map((item) => (
              <div
                key={item.num}
                className="flex items-start gap-3 p-2.5 bg-[#f8f4ee] rounded-xl border border-[#e8dfd5]"
              >
                <div className="w-7 h-7 rounded-full bg-[#2b5b4b] text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  {item.num}
                </div>
                <div>
                  <strong className="text-[#2b5b4b] text-sm block font-bold">
                    {item.text}
                  </strong>
                  <span className="text-xs text-[#315f4f]">{item.desc}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hubungi SewSmart */}
        <div className="pt-2 border-t border-[#e8dfd5] space-y-3">
          <h3 className="font-bold text-sm text-[#2b5b4b]">
            {isBm ? 'Hubungi SewSmart' : 'Contact SewSmart'}
          </h3>

          <div className="grid grid-cols-2 gap-2.5">
            <a
              href="https://wa.me/60123456789"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-[#f8f4ee] hover:bg-[#ede5dc] text-[#2b5b4b] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition border border-[#23755c]/30"
            >
              <MessageSquare className="w-4 h-4 text-[#2b5b4b]" />
              <span>WhatsApp Kami</span>
            </a>

            <a
              href="tel:0380001234"
              className="p-3 bg-[#f8f4ee] hover:bg-[#ede5dc] text-[#2b5b4b] font-bold text-xs rounded-xl border border-[#23755c]/30 flex items-center justify-center gap-2 transition"
            >
              <Phone className="w-4 h-4 text-[#2b5b4b]" />
              <span>{isBm ? 'Telefon Bantuan' : 'Call Helpline'}</span>
            </a>
          </div>

          <p className="text-[11px] text-[#315f4f]/80 text-center">
            {isBm ? 'Pegawai komuniti kami sedia membantu setiap hari 9 pagi – 6 petang.' : 'Our community officer is available daily 9am – 6pm.'}
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-3.5 bg-[#60a103] hover:bg-[#528c02] text-white font-bold rounded-2xl text-base touch-target"
        >
          {isBm ? 'Saya Faham' : 'Got it'}
        </button>
      </div>
    </div>
  );
};
