import React, { useState } from 'react';
import { AppLanguage } from '../types';
import { User, CheckCircle2, ChevronRight, Wallet, CreditCard, Bell, HelpCircle, MapPin } from 'lucide-react';

interface ProfileViewProps {
  language: AppLanguage;
  onGoToEarnings: () => void;
  onOpenHelp: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  language,
  onGoToEarnings,
  onOpenHelp
}) => {
  const isBm = language === 'bm';
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const menuItems = [
    {
      id: 'maklumat',
      title: isBm ? 'Maklumat Saya' : 'My Information',
      desc: isBm ? 'Aina Binti Ramli · PPR Pantai Dalam' : 'Aina Binti Ramli · PPR Pantai Dalam',
      icon: <User className="w-5 h-5 text-[#2b5b4b]" />,
      action: () => setActiveModal('maklumat')
    },
    {
      id: 'pendapatan',
      title: isBm ? 'Pendapatan' : 'Earnings',
      desc: isBm ? 'Baki RM124.50' : 'Balance RM124.50',
      icon: <Wallet className="w-5 h-5 text-[#2b5b4b]" />,
      action: onGoToEarnings
    },
    {
      id: 'pembayaran',
      title: isBm ? 'Kaedah Pembayaran' : 'Payment Method',
      desc: isBm ? 'Bank Simpanan Nasional (BSN)' : 'Bank Simpanan Nasional (BSN)',
      icon: <CreditCard className="w-5 h-5 text-[#2b5b4b]" />,
      action: () => setActiveModal('pembayaran')
    },
    {
      id: 'notifikasi',
      title: isBm ? 'Notifikasi' : 'Notifications',
      desc: isBm ? 'Pemberitahuan SMS & aplikasi' : 'SMS & app alerts',
      icon: <Bell className="w-5 h-5 text-[#2b5b4b]" />,
      action: () => setActiveModal('notifikasi')
    },
    {
      id: 'bantuan',
      title: isBm ? 'Bantuan' : 'Help & Support',
      desc: isBm ? 'Panduan dan talian sokongan' : 'Guides & helpline',
      icon: <HelpCircle className="w-5 h-5 text-[#2b5b4b]" />,
      action: onOpenHelp
    }
  ];

  return (
    <div className="space-y-6 pb-6">
      {/* Title */}
      <div className="pt-1">
        <h1 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
          {isBm ? 'Profil Saya' : 'My Profile'}
        </h1>
      </div>

      {/* Profile Header Card (Containers #f8f4ee) */}
      <div className="bg-[#f8f4ee] rounded-3xl p-6 shadow-sm border border-[#e8dfd5] flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-white text-[#2b5b4b] font-display font-black text-2xl flex items-center justify-center border-2 border-[#23755c]/20 shrink-0 shadow-2xs">
          A
        </div>
        <div className="space-y-1">
          <h2 className="font-display font-black text-2xl text-[#2b5b4b] leading-tight">
            Aina
          </h2>
          <div className="inline-flex items-center gap-1.5 bg-white text-[#23755c] text-xs font-bold px-2.5 py-0.5 rounded-full border border-[#23755c]/20">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#60a103]" />
            <span>{isBm ? 'Pengumpul Disahkan' : 'Verified Collector'}</span>
          </div>
          <p className="text-xs text-[#315f4f] flex items-center gap-1 pt-0.5 font-medium">
            <MapPin className="w-3.5 h-3.5 text-[#23755c]" />
            <span>PPR Pantai Dalam, Kuala Lumpur</span>
          </p>
        </div>
      </div>

      {/* Simple Clean Menu */}
      <div className="bg-[#f8f4ee] rounded-3xl overflow-hidden shadow-sm border border-[#e8dfd5] divide-y divide-[#e8dfd5]">
        {menuItems.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={item.action}
            className="w-full p-4 sm:p-5 flex items-center justify-between hover:bg-white/80 transition text-left touch-target"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-white border border-[#e8dfd5] flex items-center justify-center shrink-0">
                {item.icon}
              </div>
              <div>
                <strong className="font-display font-bold text-base text-[#2b5b4b] block">
                  {item.title}
                </strong>
                <span className="text-xs text-[#315f4f] font-medium">{item.desc}</span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#315f4f]/60" />
          </button>
        ))}
      </div>

      {/* Simple Information Modal */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 text-center border border-[#e8dfd5]">
            <h3 className="font-display font-bold text-xl text-[#2b5b4b]">
              {activeModal === 'maklumat' && (isBm ? 'Maklumat Pengumpul' : 'Collector Details')}
              {activeModal === 'pembayaran' && (isBm ? 'Kaedah Pembayaran' : 'Payment Method')}
              {activeModal === 'notifikasi' && (isBm ? 'Tetapan Notifikasi' : 'Notification Settings')}
            </h3>

            <div className="bg-[#f8f4ee] p-4 rounded-2xl text-left text-sm text-[#315f4f] space-y-2 border border-[#e8dfd5]">
              {activeModal === 'maklumat' && (
                <>
                  <p><strong>Nama:</strong> Aina Binti Ramli</p>
                  <p><strong>No. Kad Pengenalan:</strong> 880412-14-****</p>
                  <p><strong>No. Telefon:</strong> +6012-345 6789</p>
                  <p><strong>Zon Operasi:</strong> Lembah Pantai & Cheras (Radius 10 km)</p>
                </>
              )}
              {activeModal === 'pembayaran' && (
                <>
                  <p><strong>Bank:</strong> Bank Simpanan Nasional (BSN)</p>
                  <p><strong>No Akaun:</strong> 1410-0293-8812</p>
                  <p><strong>Status:</strong> Aktif & Disahkan</p>
                </>
              )}
              {activeModal === 'notifikasi' && (
                <>
                  <p>✓ <strong>Peluang Baru:</strong> SMS & WhatsApp Diaktifkan</p>
                  <p>✓ <strong>Pesanan Pembeli:</strong> Pemberitahuan Segera</p>
                  <p>✓ <strong>Bayaran Masuk:</strong> SMS Bank & SewSmart</p>
                </>
              )}
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-3 bg-[#60a103] hover:bg-[#528c02] text-white font-bold rounded-xl text-sm"
            >
              {isBm ? 'Tutup' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
