import React from 'react';
import { AppLanguage } from '../types';
import { X, ArrowRight } from 'lucide-react';

interface GoalDetailModalProps {
  language: AppLanguage;
  onClose: () => void;
  onFindOpportunities: () => void;
}

export const GoalDetailModal: React.FC<GoalDetailModalProps> = ({
  language,
  onClose,
  onFindOpportunities
}) => {
  const isBm = language === 'bm';

  const completedContributions = [
    { title: 'Kain Kapas', amount: '+RM18', date: 'Hotel Istana' },
    { title: 'Denim', amount: '+RM24', date: 'Bengkel Cheras' },
    { title: 'Kain Kapas', amount: '+RM20', date: 'Hotel Seri Pacific' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] my-auto space-y-6">
        <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
          <h2 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
            {isBm ? 'Sasaran RM100' : 'RM100 Goal'}
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-[#f8f4ee] touch-target"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Display (Containers #f8f4ee) */}
        <div className="bg-[#f8f4ee] p-5 rounded-2xl border border-[#e8dfd5] space-y-3 text-center">
          <div className="font-display font-black text-3xl sm:text-4xl text-[#2b5b4b] tracking-tight">
            RM62 <span className="text-2xl font-bold text-[#315f4f]/60">/ RM100</span>
          </div>

          <p className="text-sm font-bold text-[#23755c]">
            {isBm ? 'RM38 lagi' : 'RM38 remaining'}
          </p>

          {/* Progress bar */}
          <div className="w-full bg-white rounded-full h-3.5 overflow-hidden p-0.5 border border-[#e8dfd5]">
            <div
              className="bg-[#60a103] h-full rounded-full transition-all duration-500"
              style={{ width: '62%' }}
            ></div>
          </div>

          <p className="text-sm font-semibold text-[#23755c] pt-1">
            {isBm
              ? '“Sedikit lagi untuk capai sasaran anda.”'
              : '“Just a little more to reach your goal.”'}
          </p>
        </div>

        {/* Completed Collections that contributed to this goal */}
        <div className="space-y-3">
          <h3 className="font-bold text-sm text-[#2b5b4b]">
            {isBm ? 'Koleksi yang telah siap:' : 'Completed collections:'}
          </h3>

          <div className="space-y-2 text-sm">
            {completedContributions.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3.5 bg-[#f8f4ee] rounded-xl border border-[#e8dfd5]"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-full bg-white text-[#2b5b4b] border border-[#23755c]/20 flex items-center justify-center text-xs font-bold">
                    ✓
                  </span>
                  <div>
                    <strong className="text-[#2b5b4b] block font-bold">{item.title}</strong>
                    <span className="text-xs text-[#315f4f]">{item.date}</span>
                  </div>
                </div>
                <span className="font-black text-[#2b5b4b]">{item.amount}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Button: Cari Peluang (Buttons #60a103) */}
        <button
          type="button"
          onClick={() => {
            onClose();
            onFindOpportunities();
          }}
          className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
        >
          <span>{isBm ? 'Cari Peluang Tambahan' : 'Find More Opportunities'}</span>
          <ArrowRight className="w-5 h-5 text-white" />
        </button>
      </div>
    </div>
  );
};
