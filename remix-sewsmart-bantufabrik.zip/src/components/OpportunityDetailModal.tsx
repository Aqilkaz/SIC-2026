import React from 'react';
import { Opportunity, AppLanguage } from '../types';
import { X, MapPin, Calendar, Building2, ArrowRight } from 'lucide-react';

interface OpportunityDetailModalProps {
  opportunity: Opportunity | null;
  language: AppLanguage;
  onClose: () => void;
  onAccept: (opportunity: Opportunity) => void;
}

export const OpportunityDetailModal: React.FC<OpportunityDetailModalProps> = ({
  opportunity,
  language,
  onClose,
  onAccept
}) => {
  if (!opportunity) return null;
  const isBm = language === 'bm';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-[#e8dfd5] my-auto">
        {/* Large Fabric Photo */}
        <div className="relative h-48 sm:h-56 w-full bg-[#f8f4ee]">
          <img
            src={opportunity.photoUrl}
            alt={opportunity.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-10 h-10 rounded-full bg-white/90 backdrop-blur-md text-[#2b5b4b] flex items-center justify-center shadow-md hover:bg-white touch-target transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Section */}
        <div className="p-5 sm:p-6 space-y-5">
          {/* Main Info */}
          <div>
            <h2 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
              {opportunity.title}
            </h2>
            <div className="flex flex-wrap items-center gap-2 mt-1 text-sm font-semibold text-[#315f4f]">
              <span>{opportunity.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'}</span>
              <span>•</span>
              <span>{opportunity.distanceKm} km {isBm ? 'dari anda' : 'from you'}</span>
            </div>
            <div className="mt-2.5 bg-[#f8f4ee] text-[#2b5b4b] border border-[#23755c]/20 p-3.5 rounded-2xl flex items-baseline justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#23755c]">
                {isBm ? 'Anggaran pendapatan:' : 'Estimated earnings:'}
              </span>
              <span className="font-display font-black text-2xl text-[#2b5b4b]">
                RM{opportunity.estEarnings}
              </span>
            </div>
          </div>

          {/* Apa yang perlu anda buat? (Containers #f8f4ee) */}
          <div className="bg-[#f8f4ee] p-4 rounded-2xl border border-[#e8dfd5] space-y-2.5">
            <h3 className="font-display font-extrabold text-base text-[#2b5b4b]">
              {isBm ? 'Apa yang perlu anda buat?' : 'What do you need to do?'}
            </h3>
            <ol className="space-y-2 text-sm text-[#315f4f]">
              <li className="flex items-center gap-2.5">
                <span className="w-6 h-6 rounded-full bg-[#2b5b4b] text-white flex items-center justify-center text-xs font-bold shrink-0">
                  1
                </span>
                <span className="font-semibold">{isBm ? 'Ambil kain' : 'Pick up fabric'}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className="w-6 h-6 rounded-full bg-[#2b5b4b] text-white flex items-center justify-center text-xs font-bold shrink-0">
                  2
                </span>
                <span className="font-semibold">{isBm ? 'Bawa pulang' : 'Bring home'}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className="w-6 h-6 rounded-full bg-[#2b5b4b] text-white flex items-center justify-center text-xs font-bold shrink-0">
                  3
                </span>
                <span className="font-semibold">{isBm ? 'Asingkan kain' : 'Sort the fabric'}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className="w-6 h-6 rounded-full bg-[#2b5b4b] text-white flex items-center justify-center text-xs font-bold shrink-0">
                  4
                </span>
                <span className="font-semibold">{isBm ? 'Senaraikan dalam SewSmart' : 'List in SewSmart'}</span>
              </li>
            </ol>
          </div>

          {/* Crucial Details */}
          <div className="space-y-2 text-xs text-[#315f4f]">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-[#23755c] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#2b5b4b] block font-bold text-sm">
                  {isBm ? 'Lokasi ambil:' : 'Pickup location:'}
                </strong>
                <span>{opportunity.supplierAddress}</span>
              </div>
            </div>

            <div className="flex items-start gap-2 pt-1">
              <Calendar className="w-4 h-4 text-[#23755c] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#2b5b4b] block font-bold text-sm">
                  {isBm ? 'Tarikh akhir:' : 'Deadline:'}
                </strong>
                <span>{opportunity.deadline}</span>
              </div>
            </div>

            <div className="flex items-start gap-2 pt-1">
              <Building2 className="w-4 h-4 text-[#23755c] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#2b5b4b] block font-bold text-sm">
                  {isBm ? 'Disediakan oleh:' : 'Provided by:'}
                </strong>
                <span className="font-semibold">{opportunity.supplierName}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons (Buttons #60a103) */}
          <div className="space-y-2.5 pt-2">
            <button
              type="button"
              onClick={() => onAccept(opportunity)}
              className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-4 px-5 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
            >
              <span>{isBm ? 'Saya Nak Ambil' : 'I Want to Collect This'}</span>
              <ArrowRight className="w-5 h-5 text-white" />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-full py-2.5 text-center text-sm font-semibold text-[#315f4f]/80 hover:text-[#2b5b4b] transition"
            >
              {isBm ? 'Tidak sekarang' : 'Not now'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
