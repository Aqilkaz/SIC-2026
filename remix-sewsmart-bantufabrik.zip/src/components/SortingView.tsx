import React, { useState } from 'react';
import { FabricType, FabricCondition, AppLanguage } from '../types';
import { ArrowLeft, Camera, Minus, Plus, Check } from 'lucide-react';

interface SortingViewProps {
  language: AppLanguage;
  initialType?: FabricType;
  initialQuantity?: number;
  onBack: () => void;
  onComplete: (data: {
    fabricType: FabricType;
    condition: FabricCondition;
    quantityPieces: number;
    notes?: string;
    photoUrl: string;
  }) => void;
}

export const SortingView: React.FC<SortingViewProps> = ({
  language,
  initialType = 'Kapas',
  initialQuantity = 12,
  onBack,
  onComplete
}) => {
  const isBm = language === 'bm';

  const [selectedType, setSelectedType] = useState<FabricType>(initialType);
  const [selectedCondition, setSelectedCondition] = useState<FabricCondition>('Baik');
  const [quantity, setQuantity] = useState<number>(initialQuantity);
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [notes, setNotes] = useState('');
  const [photoSelected, setPhotoSelected] = useState(true);

  // Realistic sample photo
  const defaultPhoto = selectedType === 'Denim' 
    ? 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=600&q=80'
    : selectedType === 'Polyester'
    ? 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=600&q=80'
    : 'https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=600&q=80';

  const handleDecreaseQuantity = () => {
    if (quantity > 1) setQuantity(quantity - 1);
  };

  const handleIncreaseQuantity = () => {
    if (quantity < 100) setQuantity(quantity + 1);
  };

  const handleFinish = () => {
    onComplete({
      fabricType: selectedType,
      condition: selectedCondition,
      quantityPieces: quantity,
      notes: notes.trim() || undefined,
      photoUrl: defaultPhoto
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Bar with Back Button */}
      <div className="flex items-center gap-3 pt-1">
        <button
          type="button"
          onClick={onBack}
          className="p-2.5 rounded-full bg-[#f8f4ee] border border-[#23755c]/30 text-[#2b5b4b] hover:bg-[#ede5dc] transition touch-target"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
            {isBm ? 'Asingkan Kain' : 'Sort Fabric'}
          </h1>
          <p className="text-sm text-[#315f4f]">
            {isBm ? 'Pilih maklumat kain yang anda kumpulkan.' : 'Select details of the fabric you collected.'}
          </p>
        </div>
      </div>

      <div className="bg-[#f8f4ee] rounded-3xl p-5 sm:p-6 shadow-sm border border-[#e8dfd5] space-y-6">
        {/* 1. Jenis kain (Large selectable buttons) */}
        <div className="space-y-2.5">
          <label className="block text-base font-extrabold text-[#2b5b4b]">
            {isBm ? 'Jenis kain' : 'Fabric type'}
          </label>
          <div className="grid grid-cols-2 gap-2.5">
            {(['Kapas', 'Denim', 'Polyester', 'Lain-lain'] as FabricType[]).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setSelectedType(type)}
                className={`py-4 px-4 rounded-2xl text-base font-extrabold border-2 transition touch-target text-center flex items-center justify-center gap-2 ${
                  selectedType === type
                    ? 'bg-[#2b5b4b] text-white border-[#2b5b4b] shadow-sm'
                    : 'bg-white text-[#315f4f] border-[#e8dfd5] hover:border-[#2b5b4b]'
                }`}
              >
                <span>{type}</span>
                {selectedType === type && <Check className="w-5 h-5 text-white" />}
              </button>
            ))}
          </div>
        </div>

        {/* 2. Keadaan (Large selectable buttons) */}
        <div className="space-y-2.5">
          <label className="block text-base font-extrabold text-[#2b5b4b]">
            {isBm ? 'Keadaan' : 'Condition'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['Baik', 'Sederhana', 'Kurang baik'] as FabricCondition[]).map((cond) => (
              <button
                key={cond}
                type="button"
                onClick={() => setSelectedCondition(cond)}
                className={`py-3.5 px-2 rounded-2xl text-sm font-extrabold border-2 transition touch-target text-center ${
                  selectedCondition === cond
                    ? 'bg-[#2b5b4b] text-white border-[#2b5b4b] shadow-sm'
                    : 'bg-white text-[#315f4f] border-[#e8dfd5] hover:border-[#2b5b4b]'
                }`}
              >
                {cond}
              </button>
            ))}
          </div>
        </div>

        {/* 3. Kuantiti ([-] 12 helai (pcs) [+]) */}
        <div className="space-y-2.5 bg-white p-4 sm:p-5 rounded-2xl border border-[#e8dfd5]">
          <label className="block text-base font-extrabold text-[#2b5b4b] text-center">
            {isBm ? 'Kuantiti kain (helai / pcs):' : 'Fabric quantity (pcs):'}
          </label>
          <div className="flex items-center justify-center gap-6 pt-1">
            <button
              type="button"
              onClick={handleDecreaseQuantity}
              className="w-14 h-14 rounded-2xl bg-[#f8f4ee] border-2 border-[#23755c]/30 text-[#2b5b4b] hover:bg-[#ede5dc] active:scale-95 flex items-center justify-center font-bold text-2xl shadow-xs touch-target transition"
            >
              <Minus className="w-6 h-6" />
            </button>

            <div className="min-w-[150px] text-center">
              <span className="font-display font-extrabold text-3xl sm:text-4xl text-[#2b5b4b]">
                {quantity}
              </span>
              <span className="block text-xs font-extrabold text-[#315f4f] mt-0.5">
                {isBm ? 'helai / pcs' : 'pieces'}
              </span>
            </div>

            <button
              type="button"
              onClick={handleIncreaseQuantity}
              className="w-14 h-14 rounded-2xl bg-[#60a103] text-white hover:bg-[#528c02] active:scale-95 flex items-center justify-center font-bold text-2xl shadow-xs touch-target transition"
            >
              <Plus className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>

        {/* 4. Gambar (Large button: “📷 Ambil Gambar”) */}
        <div className="space-y-2.5">
          <label className="block text-base font-extrabold text-[#2b5b4b]">
            {isBm ? 'Gambar' : 'Photo'}
          </label>
          
          <div className="space-y-2">
            <button
              type="button"
              onClick={() => setPhotoSelected(true)}
              className="w-full py-4 px-4 rounded-2xl border-2 border-dashed border-[#23755c] bg-white hover:bg-[#ede5dc] text-[#2b5b4b] font-extrabold text-base flex items-center justify-center gap-3 transition touch-target"
            >
              <Camera className="w-6 h-6 text-[#2b5b4b]" />
              <span>{isBm ? '📷 Ambil Gambar' : '📷 Take Photo'}</span>
            </button>

            {photoSelected && (
              <div className="relative h-32 w-full rounded-2xl overflow-hidden border border-[#e8dfd5]">
                <img
                  src={defaultPhoto}
                  alt="Fabric preview"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-2 right-2 bg-[#2b5b4b]/90 text-white text-xs px-2.5 py-1 rounded-lg font-bold">
                  ✓ {isBm ? 'Gambar dirakam' : 'Photo captured'}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Optional: Tambah nota */}
        <div className="pt-1">
          {!showNoteInput ? (
            <button
              type="button"
              onClick={() => setShowNoteInput(true)}
              className="text-sm font-bold text-[#23755c] hover:underline"
            >
              + {isBm ? 'Tambah nota (pilihan)' : 'Add note (optional)'}
            </button>
          ) : (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-[#315f4f]">
                {isBm ? 'Nota tambahan' : 'Additional note'}
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={isBm ? 'Contoh: Kain bersih, sudah dilipat kemas...' : 'e.g., Clean fabric, already neatly folded...'}
                className="w-full p-3 rounded-xl border border-[#e8dfd5] text-sm focus:border-[#2b5b4b] focus:outline-none bg-white text-[#315f4f]"
                rows={2}
              />
            </div>
          )}
        </div>

        {/* Bottom Primary Button: “Selesai” (Buttons #60a103) */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleFinish}
            className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-lg py-4 px-6 rounded-2xl shadow-sm transition touch-target flex items-center justify-center gap-2"
          >
            <span>{isBm ? 'Selesai' : 'Finish'}</span>
            <Check className="w-6 h-6 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
};
