import React, { useState } from 'react';
import { BuyerProduct, AppLanguage } from '../types';
import { ShoppingBag, Search, CheckCircle2, ArrowRight, X } from 'lucide-react';

interface BuyerPortalProps {
  language: AppLanguage;
  products: BuyerProduct[];
  onSwitchToCollector: () => void;
}

export const BuyerPortal: React.FC<BuyerPortalProps> = ({
  language,
  products,
  onSwitchToCollector
}) => {
  const isBm = language === 'bm';
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('Semua');
  const [selectedProduct, setSelectedProduct] = useState<BuyerProduct | null>(null);
  const [isPurchaseSuccess, setIsPurchaseSuccess] = useState(false);

  const filtered = products.filter((p) => {
    const matchQuery = p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                       p.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchType = selectedType === 'Semua' || p.fabricType === selectedType;
    return matchQuery && matchType;
  });

  const handleBuy = () => {
    setIsPurchaseSuccess(true);
    setTimeout(() => {
      setIsPurchaseSuccess(false);
      setSelectedProduct(null);
    }, 2000);
  };

  return (
    <div className="space-y-6 pb-12 max-w-xl mx-auto">
      {/* Top Banner */}
      <div className="bg-[#2b5b4b] text-white rounded-3xl p-6 shadow-sm space-y-3">
        <div className="inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-semibold text-white">
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>{isBm ? 'Pasaran Pembeli Fabrik' : 'Fabric Buyer Marketplace'}</span>
        </div>
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl tracking-tight text-white">
          {isBm ? 'Cari Bahan Fabrik' : 'Source Fabric Materials'}
        </h1>
        <p className="text-sm text-white/90 font-medium">
          {isBm
            ? 'Beli bahan sisa fabrik yang telah diasingkan dan dibersihkan oleh wanita pengumpul B40.'
            : 'Buy pre-sorted, clean textile offcuts directly prepared by B40 women collectors.'}
        </p>
      </div>

      {/* Search Input: “Cari kain...” */}
      <div className="relative">
        <Search className="w-5 h-5 text-[#315f4f]/70 absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={isBm ? 'Cari kain...' : 'Search fabrics...'}
          className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white border border-[#e8dfd5] text-[#315f4f] font-semibold shadow-2xs focus:border-[#2b5b4b] focus:outline-none"
        />
      </div>

      {/* Simple Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
        {['Semua', 'Kapas', 'Denim', 'Lain-lain'].map((type) => (
          <button
            key={type}
            onClick={() => setSelectedType(type)}
            className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap border transition touch-target ${
              selectedType === type
                ? 'bg-[#2b5b4b] text-white border-[#2b5b4b]'
                : 'bg-[#f8f4ee] text-[#315f4f] border-[#e8dfd5] hover:border-[#2b5b4b]'
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      {/* Cards List (Containers #f8f4ee) */}
      <div className="space-y-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-[#f8f4ee] rounded-3xl p-5 shadow-sm border border-[#e8dfd5] hover:border-[#2b5b4b] transition space-y-3"
          >
            <div className="flex gap-4">
              <div className="w-24 h-24 rounded-2xl overflow-hidden bg-white shrink-0 border border-[#e8dfd5]">
                <img
                  src={item.photoUrl}
                  alt={item.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="font-display font-bold text-lg text-[#2b5b4b] truncate">
                  {item.title}
                </h3>
                <p className="text-xs text-[#315f4f] mt-0.5">
                  {item.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'} · {isBm ? `Keadaan ${item.condition.toLowerCase()}` : `${item.condition} condition`}
                </p>
                <div className="mt-2 flex items-baseline justify-between">
                  <span className="font-display font-black text-xl text-[#2b5b4b]">
                    RM{item.pricePerPiece.toFixed(2)}/{isBm ? 'helai (pc)' : 'pc'}
                  </span>
                  <span className="text-xs text-[#23755c] font-semibold">{item.location}</span>
                </div>
              </div>
            </div>

            {/* Button: “Lihat Bahan” (Buttons #60a103) */}
            <button
              type="button"
              onClick={() => setSelectedProduct(item)}
              className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-sm py-3 px-4 rounded-xl transition flex items-center justify-center gap-2 touch-target"
            >
              <span>{isBm ? 'Lihat Bahan' : 'View Material'}</span>
              <ArrowRight className="w-4 h-4 text-white" />
            </button>
          </div>
        ))}
      </div>

      {/* Switch back to B40 preview prompt */}
      <div className="text-center p-4 bg-[#f8f4ee] rounded-2xl border border-[#e8dfd5]">
        <p className="text-xs font-bold text-[#2b5b4b]">
          {isBm ? 'Ingin kembali ke paparan utama Aina (Pengumpul B40)?' : 'Want to return to Aina’s (B40 Collector) screen?'}
        </p>
        <button
          onClick={onSwitchToCollector}
          className="mt-2 text-xs font-extrabold underline text-[#2b5b4b] hover:text-[#23755c]"
        >
          {isBm ? 'Tukar ke Pengalaman B40' : 'Switch to B40 Experience'} →
        </button>
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] my-auto space-y-5">
            {!isPurchaseSuccess ? (
              <>
                <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
                  <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                    {selectedProduct.title}
                  </h3>
                  <button
                    onClick={() => setSelectedProduct(null)}
                    className="p-1.5 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-[#f8f4ee] touch-target"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="h-44 w-full rounded-2xl overflow-hidden border border-[#e8dfd5]">
                  <img
                    src={selectedProduct.photoUrl}
                    alt={selectedProduct.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="bg-[#f8f4ee] p-4 rounded-2xl border border-[#e8dfd5] space-y-2 text-sm">
                  <p className="text-xs text-[#315f4f]">{selectedProduct.description}</p>
                  <div className="flex justify-between font-medium pt-2 border-t border-[#e8dfd5]">
                    <span className="text-[#315f4f]">{isBm ? 'Kuantiti Tersedia:' : 'Available Quantity:'}</span>
                    <strong className="text-[#2b5b4b]">{selectedProduct.quantityPieces} {isBm ? 'helai (pcs) tersedia' : 'pcs available'}</strong>
                  </div>
                  <div className="flex justify-between font-medium">
                    <span className="text-[#315f4f]">{isBm ? 'Kadar se-helai (pc):' : 'Rate per piece (pc):'}</span>
                    <strong className="text-[#2b5b4b]">RM{selectedProduct.pricePerPiece.toFixed(2)}/{isBm ? 'helai (pc)' : 'pc'}</strong>
                  </div>
                  <div className="flex justify-between text-base font-bold text-[#2b5b4b] pt-2 border-t border-[#e8dfd5]">
                    <span>{isBm ? 'Jumlah bayaran:' : 'Total amount:'}</span>
                    <span>RM{selectedProduct.totalPrice}</span>
                  </div>
                </div>

                {/* Button: “Beli Bahan” (Buttons #60a103) */}
                <button
                  type="button"
                  onClick={handleBuy}
                  className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition touch-target"
                >
                  {isBm ? 'Beli Bahan' : 'Buy Material'}
                </button>
              </>
            ) : (
              <div className="py-8 text-center space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 rounded-full bg-[#f8f4ee] text-[#2b5b4b] mx-auto flex items-center justify-center border border-[#23755c]/20">
                  <CheckCircle2 className="w-10 h-10 text-[#60a103]" />
                </div>
                <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                  {isBm ? 'Pesanan Berjaya! 🎉' : 'Order Successful! 🎉'}
                </h3>
                <p className="text-sm text-[#315f4f]">
                  {isBm
                    ? 'Pesanan anda telah dihantar kepada pengumpul komuniti SewSmart.'
                    : 'Your order has been routed to the SewSmart community collector.'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
