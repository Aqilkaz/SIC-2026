import React from 'react';
import { AppRole, AppLanguage } from '../types';
import { HelpCircle } from 'lucide-react';

interface TopBarProps {
  currentRole: AppRole;
  setRole: (role: AppRole) => void;
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  onOpenHelp: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentRole,
  setRole,
  language,
  setLanguage,
  onOpenHelp
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#ffffff]/98 backdrop-blur-sm border-b border-[#e8dfd5] shadow-xs">
      {/* Top Prototype Context Switcher (Upper navigation bar with bigger font size & main green) */}
      <div className="bg-[#2b5b4b] text-white px-3 sm:px-4 py-2 text-sm">
        <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-[#60a103] animate-pulse"></span>
            <span className="text-white/90 text-xs sm:text-sm font-semibold">
              {language === 'bm' ? 'Peranan Semasa:' : 'Current Role:'}
            </span>
            <span className="font-extrabold text-white text-xs sm:text-sm bg-white/20 px-2.5 py-0.5 rounded-md tracking-wide">
              {currentRole === 'b40' && 'Wanita B40 (Aina)'}
              {currentRole === 'supplier' && 'Pembekal (Hotel/Kilang)'}
              {currentRole === 'buyer' && 'Pembeli (EcoCraft)'}
              {currentRole === 'landing' && 'Laman Utama Awam'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setRole('b40')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition touch-target flex items-center justify-center ${
                currentRole === 'b40' ? 'bg-[#ffffff] text-[#2b5b4b] shadow-xs' : 'text-white/90 hover:bg-white/15'
              }`}
            >
              Aina (B40)
            </button>
            <button
              onClick={() => setRole('supplier')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition touch-target flex items-center justify-center ${
                currentRole === 'supplier' ? 'bg-[#ffffff] text-[#2b5b4b] shadow-xs' : 'text-white/90 hover:bg-white/15'
              }`}
            >
              {language === 'bm' ? 'Pembekal' : 'Supplier'}
            </button>
            <button
              onClick={() => setRole('buyer')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition touch-target flex items-center justify-center ${
                currentRole === 'buyer' ? 'bg-[#ffffff] text-[#2b5b4b] shadow-xs' : 'text-white/90 hover:bg-white/15'
              }`}
            >
              {language === 'bm' ? 'Pembeli' : 'Buyer'}
            </button>
            <button
              onClick={() => setRole('landing')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition touch-target flex items-center justify-center ${
                currentRole === 'landing' ? 'bg-[#ffffff] text-[#2b5b4b] shadow-xs' : 'text-white/90 hover:bg-white/15'
              }`}
            >
              {language === 'bm' ? 'Laman Awam' : 'Public'}
            </button>
          </div>
        </div>
      </div>

      {/* Main App Brand & Header */}
      <div className="max-w-5xl mx-auto px-4 py-3.5 flex items-center justify-between">
        <div 
          onClick={() => setRole('landing')}
          className="flex items-center gap-3 cursor-pointer"
        >
          <div className="w-11 h-11 rounded-2xl bg-[#2b5b4b] text-white flex items-center justify-center font-extrabold text-2xl shadow-xs">
            <span className="font-display">S</span>
          </div>
          <div>
            <div className="flex items-center gap-2 leading-none">
              <span className="font-display font-black text-2xl sm:text-3xl text-[#2b5b4b] tracking-tight">SewSmart</span>
              <span className="text-xs bg-[#f8f4ee] text-[#23755c] font-bold px-2 py-0.5 rounded-md border border-[#23755c]/30">MY</span>
            </div>
            <p className="text-xs sm:text-sm text-[#315f4f] font-semibold mt-1">
              {language === 'bm' ? 'Kurang Sisa. Lebih Peluang.' : 'Less Waste. More Opportunities.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Language Toggle (BM / EN) */}
          <button
            onClick={() => setLanguage(language === 'bm' ? 'en' : 'bm')}
            className="text-sm sm:text-base font-bold px-3.5 py-2 rounded-xl border border-[#23755c]/30 bg-[#f8f4ee] text-[#2b5b4b] hover:bg-[#ede5dc] transition touch-target flex items-center justify-center shadow-2xs"
            title="Tukar Bahasa"
          >
            {language === 'bm' ? 'BM 🇲🇾' : 'EN 🇬🇧'}
          </button>

          {/* Quick Help Button - styled with Buttons #60a103 */}
          <button
            onClick={onOpenHelp}
            className="flex items-center gap-1.5 text-sm sm:text-base font-bold px-4 py-2 rounded-xl bg-[#60a103] hover:bg-[#528c02] text-white shadow-xs transition touch-target"
          >
            <HelpCircle className="w-5 h-5 text-white" />
            <span className="hidden sm:inline">{language === 'bm' ? 'Bantuan' : 'Help'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
