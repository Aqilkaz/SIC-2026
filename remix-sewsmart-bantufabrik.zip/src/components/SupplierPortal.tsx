import React, { useState } from 'react';
import { SupplierListing, AppLanguage } from '../types';
import { Building2, Plus, CheckCircle2, Camera, X } from 'lucide-react';

interface SupplierPortalProps {
  language: AppLanguage;
  listings: SupplierListing[];
  onAddListing: (newListing: SupplierListing) => void;
  onSwitchToCollector: () => void;
}

export const SupplierPortal: React.FC<SupplierPortalProps> = ({
  language,
  listings,
  onAddListing,
  onSwitchToCollector
}) => {
  const isBm = language === 'bm';
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Form State
  const [fabricType, setFabricType] = useState('Kain Kapas (Cadar/Tuala)');
  const [quantity, setQuantity] = useState(20);
  const [condition, setCondition] = useState('Baik');
  const [location, setLocation] = useState('Hotel Istana Kuala Lumpur, Jalan Raja Chulan');
  const [date, setDate] = useState('2026-09-24');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newListing: SupplierListing = {
      id: `sup-${Date.now()}`,
      fabricType,
      quantityPieces: Number(quantity),
      condition,
      location,
      dateAvailable: date,
      status: 'Menunggu pengumpul'
    };

    onAddListing(newListing);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setIsFormOpen(false);
    }, 2000);
  };

  return (
    <div className="space-y-6 pb-12 max-w-xl mx-auto">
      {/* Supplier Banner */}
      <div className="bg-[#2b5b4b] text-white rounded-3xl p-6 sm:p-7 shadow-sm space-y-4">
        <div className="inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-semibold text-white">
          <Building2 className="w-3.5 h-3.5" />
          <span>{isBm ? 'Portal Pembekal & Perniagaan' : 'Supplier & Business Portal'}</span>
        </div>

        <h1 className="font-display font-extrabold text-2xl sm:text-3xl tracking-tight text-white">
          {isBm ? 'Beri Fabrik Anda Peluang Kedua' : 'Give Your Fabric a Second Chance'}
        </h1>

        <p className="text-sm text-white/90 leading-relaxed font-medium">
          {isBm
            ? 'Salurkan lebihan tekstil industri, hotel dan kilang kepada komuniti wanita B40 tanpa sebarang kos pelupusan.'
            : 'Channel surplus industrial, hotel, and factory textiles to B40 women collectors at zero disposal cost.'}
        </p>

        {/* Large Button: “Tambah Fabrik” (Buttons #60a103) */}
        <button
          type="button"
          onClick={() => setIsFormOpen(true)}
          className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
        >
          <Plus className="w-5 h-5 text-white" />
          <span>{isBm ? 'Tambah Fabrik' : 'Add Fabric'}</span>
        </button>
      </div>

      {/* Current Status List (Containers #f8f4ee) */}
      <div className="bg-[#f8f4ee] rounded-3xl p-5 sm:p-6 shadow-sm border border-[#e8dfd5] space-y-4">
        <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
          <h2 className="font-display font-bold text-lg text-[#2b5b4b]">
            {isBm ? 'Status Fabrik Disediakan' : 'Supplied Fabric Status'}
          </h2>
          <span className="text-xs font-bold text-[#2b5b4b] bg-white px-2.5 py-1 rounded-full border border-[#23755c]/20">
            {listings.length} {isBm ? 'Item' : 'Items'}
          </span>
        </div>

        <div className="space-y-3">
          {listings.map((item) => {
            const isWaiting = item.status === 'Menunggu pengumpul';
            const isMatched = item.status === 'Pengumpul ditemui';

            return (
              <div
                key={item.id}
                className="p-4 bg-white rounded-2xl border border-[#e8dfd5] space-y-2.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-extrabold text-base text-[#2b5b4b]">
                      {item.fabricType}
                    </h3>
                    <p className="text-xs text-[#315f4f]">
                      {item.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'} · {item.condition} · {item.location}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                      isWaiting
                        ? 'bg-amber-50 text-amber-900 border-amber-300'
                        : isMatched
                        ? 'bg-blue-50 text-blue-900 border-blue-300'
                        : 'bg-emerald-50 text-emerald-900 border-emerald-300'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                {item.collectorName && (
                  <p className="text-xs text-[#2b5b4b] font-bold bg-[#f8f4ee] p-2 rounded-xl border border-[#23755c]/20">
                    ✓ {isBm ? `Dituntut oleh: ${item.collectorName}` : `Claimed by: ${item.collectorName}`}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Switch back to B40 preview prompt */}
      <div className="text-center p-4 bg-[#f8f4ee] rounded-2xl border border-[#e8dfd5]">
        <p className="text-xs font-bold text-[#2b5b4b]">
          {isBm ? 'Ingin melihat sudut pandang Aina (Pengumpul B40)?' : 'Want to preview from Aina’s (B40 Collector) view?'}
        </p>
        <button
          onClick={onSwitchToCollector}
          className="mt-2 text-xs font-extrabold underline text-[#2b5b4b] hover:text-[#23755c]"
        >
          {isBm ? 'Tukar ke Pengalaman B40' : 'Switch to B40 Experience'} →
        </button>
      </div>

      {/* Add Fabric Modal Form */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-[#e8dfd5] my-auto space-y-5">
            {!isSuccess ? (
              <>
                <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
                  <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                    {isBm ? 'Tambah Sisa Fabrik' : 'Add Fabric Waste'}
                  </h3>
                  <button
                    onClick={() => setIsFormOpen(false)}
                    className="p-1.5 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-[#f8f4ee] touch-target"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4 text-sm">
                  {/* Photo prompt */}
                  <div className="border-2 border-dashed border-[#23755c]/40 p-3 rounded-2xl text-center bg-[#f8f4ee] cursor-pointer hover:bg-[#ede5dc] transition">
                    <Camera className="w-6 h-6 text-[#2b5b4b] mx-auto mb-1" />
                    <span className="text-xs font-bold text-[#2b5b4b] block">
                      {isBm ? '📷 Gambar Fabrik (Pilihan)' : '📷 Fabric Photo (Optional)'}
                    </span>
                  </div>

                  {/* Jenis fabrik */}
                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Jenis fabrik' : 'Fabric type'}
                    </label>
                    <select
                      value={fabricType}
                      onChange={(e) => setFabricType(e.target.value)}
                      className="w-full p-3 rounded-xl border border-[#e8dfd5] bg-[#f8f4ee] font-semibold text-[#315f4f] focus:border-[#2b5b4b] focus:outline-none"
                    >
                      <option value="Kain Kapas (Cadar/Tuala)">Kain Kapas (Cadar/Tuala)</option>
                      <option value="Potongan Denim & Jins">Potongan Denim & Jins</option>
                      <option value="Polyester & Jersi">Polyester & Jersi</option>
                      <option value="Kain Campuran / Lain-lain">Kain Campuran / Lain-lain</option>
                    </select>
                  </div>

                  {/* Anggaran kuantiti */}
                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Anggaran kuantiti (helai / pcs)' : 'Estimated quantity (pieces / pcs)'}
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(Number(e.target.value))}
                      className="w-full p-3 rounded-xl border border-[#e8dfd5] bg-[#f8f4ee] font-semibold text-[#315f4f] focus:border-[#2b5b4b] focus:outline-none"
                      required
                    />
                  </div>

                  {/* Keadaan */}
                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Keadaan' : 'Condition'}
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {['Baik', 'Sederhana', 'Kurang baik'].map((c) => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => setCondition(c)}
                          className={`py-2 px-2 rounded-xl text-xs font-bold border transition ${
                            condition === c
                              ? 'bg-[#2b5b4b] text-white border-[#2b5b4b]'
                              : 'bg-[#f8f4ee] text-[#315f4f] border-[#e8dfd5]'
                          }`}
                        >
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Lokasi */}
                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Lokasi pengambilan' : 'Pickup location'}
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full p-3 rounded-xl border border-[#e8dfd5] bg-[#f8f4ee] font-semibold text-[#315f4f] focus:border-[#2b5b4b] focus:outline-none"
                      required
                    />
                  </div>

                  {/* Tarikh boleh diambil */}
                  <div>
                    <label className="block text-xs font-bold text-[#315f4f] mb-1">
                      {isBm ? 'Tarikh boleh diambil' : 'Available pickup date'}
                    </label>
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full p-3 rounded-xl border border-[#e8dfd5] bg-[#f8f4ee] font-semibold text-[#315f4f] focus:border-[#2b5b4b] focus:outline-none"
                      required
                    />
                  </div>

                  {/* Button: “Hantar” (Buttons #60a103) */}
                  <button
                    type="submit"
                    className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition touch-target"
                  >
                    {isBm ? 'Hantar' : 'Submit'}
                  </button>
                </form>
              </>
            ) : (
              <div className="py-8 text-center space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 rounded-full bg-[#f8f4ee] text-[#2b5b4b] mx-auto flex items-center justify-center border border-[#23755c]/20">
                  <CheckCircle2 className="w-10 h-10 text-[#60a103]" />
                </div>
                <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                  {isBm ? 'Fabrik anda sudah tersedia untuk dikutip.' : 'Your fabric is now ready for collection.'}
                </h3>
                <p className="text-sm text-[#315f4f]">
                  {isBm
                    ? 'Status semasa: Menunggu pengumpul berdekatan.'
                    : 'Current status: Waiting for nearby collectors.'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
