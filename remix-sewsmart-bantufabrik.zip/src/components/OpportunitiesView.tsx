import React, { useState } from 'react';
import { Opportunity, AppLanguage } from '../types';
import { SlidersHorizontal, ChevronRight, X } from 'lucide-react';

interface OpportunitiesViewProps {
  opportunities: Opportunity[];
  language: AppLanguage;
  onSelectOpportunity: (opp: Opportunity) => void;
}

export const OpportunitiesView: React.FC<OpportunitiesViewProps> = ({
  opportunities,
  language,
  onSelectOpportunity
}) => {
  const isBm = language === 'bm';
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedFabric, setSelectedFabric] = useState<string>('Semua');
  const [selectedDistance, setSelectedDistance] = useState<number>(20);

  // Filter logic
  const filteredOpportunities = opportunities.filter((opp) => {
    const matchFabric =
      selectedFabric === 'Semua' || opp.fabricType.toLowerCase().includes(selectedFabric.toLowerCase());
    const matchDistance = opp.distanceKm <= selectedDistance;
    return matchFabric && matchDistance;
  });

  return (
    <div className="space-y-4 pb-6">
      {/* Top Header & Filter Button */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h1 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
            {isBm ? 'Peluang Berdekatan' : 'Nearby Opportunities'}
          </h1>
          <p className="text-sm text-[#315f4f] mt-0.5">
            {filteredOpportunities.length} {isBm ? 'peluang dijumpai' : 'opportunities found'}
          </p>
        </div>

        {/* Simple "Tapis" Button */}
        <button
          type="button"
          onClick={() => setIsFilterOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#f8f4ee] border border-[#23755c]/30 text-[#2b5b4b] font-extrabold text-sm shadow-2xs hover:bg-[#ede5dc] transition touch-target"
        >
          <SlidersHorizontal className="w-4 h-4 text-[#2b5b4b]" />
          <span>{isBm ? 'Tapis' : 'Filter'}</span>
          {(selectedFabric !== 'Semua' || selectedDistance < 20) && (
            <span className="w-2 h-2 rounded-full bg-[#60a103]"></span>
          )}
        </button>
      </div>

      {/* Large Simple Cards (Containers #f8f4ee) */}
      <div className="space-y-4">
        {filteredOpportunities.length === 0 ? (
          <div className="bg-[#f8f4ee] rounded-3xl p-8 text-center border border-[#e8dfd5] space-y-3">
            <p className="text-base text-[#315f4f] font-medium">
              {isBm ? 'Tiada peluang dengan tapisan ini.' : 'No opportunities match your filter.'}
            </p>
            <button
              onClick={() => {
                setSelectedFabric('Semua');
                setSelectedDistance(20);
              }}
              className="px-4 py-2 bg-[#60a103] text-white font-bold rounded-xl text-sm"
            >
              {isBm ? 'Set Semula Tapisan' : 'Reset Filter'}
            </button>
          </div>
        ) : (
          filteredOpportunities.map((opp) => (
            <div
              key={opp.id}
              className="bg-[#f8f4ee] rounded-3xl p-5 shadow-sm border border-[#e8dfd5] hover:border-[#2b5b4b] transition space-y-4"
            >
              <div>
                <h3 className="font-display font-extrabold text-2xl text-[#2b5b4b]">
                  {opp.title}
                </h3>
                <p className="text-xs text-[#315f4f]/80 font-semibold mt-0.5">
                  {opp.supplierName}
                </p>
              </div>

              {/* Core 4 simple items with icons */}
              <div className="grid grid-cols-2 gap-2.5 bg-white p-3.5 rounded-2xl border border-[#e8dfd5] text-sm">
                <div className="flex items-center gap-2 text-[#315f4f]">
                  <span className="text-base">📍</span>
                  <span className="font-semibold">
                    {opp.distanceKm} km {isBm ? 'dari anda' : 'from you'}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[#315f4f]">
                  <span className="text-base">📦</span>
                  <span className="font-semibold">{opp.quantityPieces} {isBm ? 'helai (pcs)' : 'pcs'}</span>
                </div>

                <div className="flex items-center gap-2 text-[#2b5b4b] col-span-2">
                  <span className="text-base">💰</span>
                  <span className="font-extrabold text-base">
                    {isBm ? 'Anggaran' : 'Est.'} RM{opp.estEarnings}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[#315f4f]/80 col-span-2 text-xs font-medium">
                  <span className="text-sm">📅</span>
                  <span>
                    {isBm ? 'Ambil sebelum' : 'Collect before'} <strong className="text-[#315f4f]">{opp.deadline}</strong>
                  </span>
                </div>
              </div>

              {/* Large Button: “Lihat” (Buttons #60a103) */}
              <button
                type="button"
                onClick={() => onSelectOpportunity(opp)}
                className="w-full bg-[#60a103] hover:bg-[#528c02] active:scale-[0.99] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition flex items-center justify-center gap-2 touch-target"
              >
                <span>{isBm ? 'Lihat' : 'View'}</span>
                <ChevronRight className="w-5 h-5 text-white" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Simple Bottom Sheet Filter Modal */}
      {isFilterOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl border border-[#e8dfd5] space-y-6">
            <div className="flex items-center justify-between border-b border-[#e8dfd5] pb-3">
              <h3 className="font-display font-extrabold text-xl text-[#2b5b4b]">
                {isBm ? 'Tapis Peluang' : 'Filter Opportunities'}
              </h3>
              <button
                onClick={() => setIsFilterOpen(false)}
                className="p-2 text-[#315f4f] hover:text-[#2b5b4b] rounded-full hover:bg-slate-100 touch-target"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 1. Jenis Kain */}
            <div className="space-y-2.5">
              <label className="block text-sm font-bold text-[#315f4f]">
                {isBm ? 'Jenis kain' : 'Fabric type'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['Semua', 'Kapas', 'Denim', 'Polyester', 'Lain-lain'].map((fab) => (
                  <button
                    key={fab}
                    type="button"
                    onClick={() => setSelectedFabric(fab)}
                    className={`py-3 px-3 rounded-xl text-sm font-bold border transition touch-target text-center ${
                      selectedFabric === fab
                        ? 'bg-[#2b5b4b] text-white border-[#2b5b4b] shadow-xs'
                        : 'bg-[#f8f4ee] text-[#315f4f] border-[#23755c]/20 hover:border-[#2b5b4b]'
                    }`}
                  >
                    {fab}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Jarak */}
            <div className="space-y-2.5">
              <label className="block text-sm font-bold text-[#315f4f]">
                {isBm ? 'Jarak' : 'Distance'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[5, 10, 20].map((dist) => (
                  <button
                    key={dist}
                    type="button"
                    onClick={() => setSelectedDistance(dist)}
                    className={`py-3 px-3 rounded-xl text-sm font-bold border transition touch-target text-center ${
                      selectedDistance === dist
                        ? 'bg-[#2b5b4b] text-white border-[#2b5b4b] shadow-xs'
                        : 'bg-[#f8f4ee] text-[#315f4f] border-[#23755c]/20 hover:border-[#2b5b4b]'
                    }`}
                  >
                    {dist} km
                  </button>
                ))}
              </div>
            </div>

            {/* Large Button: Tunjukkan Peluang (Buttons #60a103) */}
            <button
              type="button"
              onClick={() => setIsFilterOpen(false)}
              className="w-full bg-[#60a103] hover:bg-[#528c02] text-white font-extrabold text-base py-3.5 px-4 rounded-2xl shadow-sm transition touch-target"
            >
              {isBm ? 'Tunjukkan Peluang' : 'Show Opportunities'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
