export type AppRole = 'b40' | 'supplier' | 'buyer' | 'landing';
export type AppLanguage = 'bm' | 'en';
export type B40Tab = 'utama' | 'peluang' | 'pendapatan' | 'profil';

export type FabricType = 'Kapas' | 'Denim' | 'Polyester' | 'Lain-lain' | 'Linen' | 'Sutera';
export type FabricCondition = 'Baik' | 'Sederhana' | 'Kurang baik';

export interface Opportunity {
  id: string;
  title: string;
  fabricType: FabricType;
  quantityPieces: number;
  distanceKm: number;
  estEarnings: number;
  deadline: string;
  supplierName: string;
  supplierLocation: string;
  supplierAddress: string;
  description: string;
  photoUrl: string;
  pickupNote: string;
}

export type CollectionStatus = 
  | 'belum_diambil'   // Step 1: Accepted, waiting to pick up
  | 'sudah_diambil'   // Step 2: Picked up, at home
  | 'diasingkan'      // Step 3: Sorted
  | 'disenaraikan'    // Step 4: Listed on platform
  | 'ada_pembeli'     // Step 5: Buyer matched
  | 'sudah_dijual'    // Step 6: Payment processing / completed
  | 'selesai';

export interface ActiveCollection {
  id: string;
  opportunityId: string;
  fabricType: FabricType;
  quantityPieces: number;
  condition: FabricCondition;
  status: CollectionStatus;
  currentStep: number; // 1 to 6
  estEarnings: number;
  photoUrl: string;
  supplierName: string;
  notes?: string;
  buyerName?: string;
  buyerDemand?: string;
  buyerPayment?: number;
}

export interface Transaction {
  id: string;
  title: string;
  date: string;
  fabricType: string;
  amount: number;
  status: 'Sudah dibayar' | 'Sedang diproses';
}

export interface SupplierListing {
  id: string;
  fabricType: string;
  quantityPieces: number;
  condition: string;
  location: string;
  dateAvailable: string;
  status: 'Menunggu pengumpul' | 'Pengumpul ditemui' | 'Sudah dikutip';
  collectorName?: string;
}

export interface BuyerProduct {
  id: string;
  title: string;
  fabricType: FabricType;
  quantityPieces: number;
  condition: FabricCondition;
  pricePerPiece: number;
  totalPrice: number;
  location: string;
  photoUrl: string;
  collectorName: string;
  description: string;
}
