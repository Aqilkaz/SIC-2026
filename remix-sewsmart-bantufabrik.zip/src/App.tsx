import React, { useState } from 'react';
import {
  AppRole,
  AppLanguage,
  B40Tab,
  Opportunity,
  ActiveCollection,
  Transaction,
  SupplierListing,
  BuyerProduct,
  FabricType,
  FabricCondition
} from './types';
import {
  INITIAL_OPPORTUNITIES,
  INITIAL_ACTIVE_COLLECTION,
  INITIAL_TRANSACTIONS,
  INITIAL_SUPPLIER_LISTINGS,
  INITIAL_BUYER_PRODUCTS
} from './data/initialData';

import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { B40HomeView } from './components/B40HomeView';
import { OpportunitiesView } from './components/OpportunitiesView';
import { OpportunityDetailModal } from './components/OpportunityDetailModal';
import { AcceptConfirmationModal } from './components/AcceptConfirmationModal';
import { SortingView } from './components/SortingView';
import { ListingPreviewModal } from './components/ListingPreviewModal';
import { BuyerMatchModal } from './components/BuyerMatchModal';
import { PaymentSuccessModal } from './components/PaymentSuccessModal';
import { EarningsView } from './components/EarningsView';
import { GoalDetailModal } from './components/GoalDetailModal';
import { HelpModal } from './components/HelpModal';
import { ProfileView } from './components/ProfileView';
import { SupplierPortal } from './components/SupplierPortal';
import { BuyerPortal } from './components/BuyerPortal';
import { LandingPageView } from './components/LandingPageView';

export default function App() {
  // 1. Role: Default is landing page as requested
  const [currentRole, setCurrentRole] = useState<AppRole>('landing');

  // 2. Language: Default is simple Bahasa Malaysia with small toggle
  const [language, setLanguage] = useState<AppLanguage>('bm');

  // 3. Tab: 4 items only (Utama, Peluang, Pendapatan, Profil)
  const [activeTab, setActiveTab] = useState<B40Tab>('utama');

  // 4. Data states
  const [opportunities, setOpportunities] = useState<Opportunity[]>(INITIAL_OPPORTUNITIES);
  const [activeCollection, setActiveCollection] = useState<ActiveCollection | null>(INITIAL_ACTIVE_COLLECTION);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [supplierListings, setSupplierListings] = useState<SupplierListing[]>(INITIAL_SUPPLIER_LISTINGS);
  const [buyerProducts, setBuyerProducts] = useState<BuyerProduct[]>(INITIAL_BUYER_PRODUCTS);

  // 5. Modal & Interactive view states
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [acceptedOpportunity, setAcceptedOpportunity] = useState<Opportunity | null>(null);
  const [isSortingActive, setIsSortingActive] = useState(false);
  const [sortingDataForListing, setSortingDataForListing] = useState<{
    fabricType: FabricType;
    condition: FabricCondition;
    quantityPieces: number;
    notes?: string;
    photoUrl: string;
  } | null>(null);

  const [isBuyerMatchOpen, setIsBuyerMatchOpen] = useState(false);
  const [isPaymentSuccessOpen, setIsPaymentSuccessOpen] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);

  // Handlers for B40 Woman Journey: CARI → AMBIL → ASINGKAN → SENARAIKAN → JUAL → DAPAT BAYARAN

  // Step 1: Accept opportunity (AMBIL)
  const handleAcceptOpportunity = (opp: Opportunity) => {
    setSelectedOpportunity(null);
    setAcceptedOpportunity(opp);

    // Update active collection
    setActiveCollection({
      id: `col-${Date.now().toString().slice(-4)}`,
      opportunityId: opp.id,
      fabricType: opp.fabricType,
      quantityPieces: opp.quantityPieces,
      condition: 'Baik',
      status: 'belum_diambil',
      currentStep: 1, // Step 1: Accepted, proceed to pick up
      estEarnings: opp.estEarnings,
      photoUrl: opp.photoUrl,
      supplierName: opp.supplierName,
      buyerName: 'EcoCraft Malaysia',
      buyerDemand: '10–20 helai (pcs) kain kapas',
      buyerPayment: 60
    });
  };

  // Step 2 & 3: Completed sorting (ASINGKAN)
  const handleSortingComplete = (data: {
    fabricType: FabricType;
    condition: FabricCondition;
    quantityPieces: number;
    notes?: string;
    photoUrl: string;
  }) => {
    setIsSortingActive(false);
    setSortingDataForListing(data);
  };

  // Step 4: Confirm listing (SENARAIKAN)
  const handleConfirmListing = () => {
    if (activeCollection && sortingDataForListing) {
      setActiveCollection({
        ...activeCollection,
        fabricType: sortingDataForListing.fabricType,
        quantityPieces: sortingDataForListing.quantityPieces,
        condition: sortingDataForListing.condition,
        status: 'disenaraikan',
        currentStep: 4, // Step 4: Listed
        notes: sortingDataForListing.notes
      });
    }
  };

  // Step 5: Buyer matched and accepted order (JUAL / ADA PEMBELI!)
  const handleAcceptBuyerOrder = () => {
    setIsBuyerMatchOpen(false);
    setIsPaymentSuccessOpen(true);

    if (activeCollection) {
      setActiveCollection({
        ...activeCollection,
        status: 'sudah_dijual',
        currentStep: 6 // Step 6: Payment received
      });
    }

    // Add +RM18 to transactions
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: `Kain ${activeCollection?.fabricType || 'Kapas'} (EcoCraft)`,
      date: 'Hari ini',
      fabricType: activeCollection?.fabricType || 'Kapas',
      amount: 18,
      status: 'Sudah dibayar'
    };
    setTransactions([newTx, ...transactions]);
  };

  const handleWithdrawSuccess = (amount: number) => {
    // Record withdrawal transaction
    const withdrawTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: language === 'bm' ? 'Pengeluaran ke BSN' : 'Withdrawal to BSN',
      date: 'Hari ini',
      fabricType: '-',
      amount: amount,
      status: 'Sudah dibayar'
    };
    // Handled visually inside EarningsView
  };

  const handleAddSupplierListing = (newListing: SupplierListing) => {
    setSupplierListings([newListing, ...supplierListings]);
  };

  return (
    <div className="min-h-screen bg-[#ffffff] text-[#315f4f] flex flex-col font-sans">
      {/* Persistent Top Navigation Bar */}
      <TopBar
        currentRole={currentRole}
        setRole={(role) => {
          setCurrentRole(role);
          if (role === 'b40') setActiveTab('utama');
        }}
        language={language}
        setLanguage={setLanguage}
        onOpenHelp={() => setIsHelpModalOpen(true)}
      />

      {/* Main Responsive Canvas */}
      <main className={`flex-1 w-full mx-auto px-4 pt-4 ${currentRole === 'landing' ? 'max-w-5xl pb-12' : 'max-w-xl pb-28'}`}>
        {/* VIEW 1: B40 WOMAN PRIMARY EXPERIENCE (DEFAULT) */}
        {currentRole === 'b40' && (
          <>
            {isSortingActive ? (
              <SortingView
                language={language}
                initialType={activeCollection?.fabricType || 'Kapas'}
                initialQuantity={activeCollection?.quantityPieces || 12}
                onBack={() => setIsSortingActive(false)}
                onComplete={handleSortingComplete}
              />
            ) : (
              <>
                {/* 1. Tab: Utama (Home) */}
                {activeTab === 'utama' && (
                  <B40HomeView
                    language={language}
                    opportunities={opportunities}
                    activeCollection={activeCollection}
                    onSelectOpportunity={(opp) => setSelectedOpportunity(opp)}
                    onGoToOpportunities={() => setActiveTab('peluang')}
                    onOpenGoal={() => setIsGoalModalOpen(true)}
                    onOpenSorting={() => setIsSortingActive(true)}
                    onOpenBuyerNotification={() => setIsBuyerMatchOpen(true)}
                    onOpenPaymentNotification={() => setIsPaymentSuccessOpen(true)}
                  />
                )}

                {/* 2. Tab: Peluang (Opportunities) */}
                {activeTab === 'peluang' && (
                  <OpportunitiesView
                    opportunities={opportunities}
                    language={language}
                    onSelectOpportunity={(opp) => setSelectedOpportunity(opp)}
                  />
                )}

                {/* 3. Tab: Pendapatan (Earnings) */}
                {activeTab === 'pendapatan' && (
                  <EarningsView
                    language={language}
                    transactions={transactions}
                    onWithdrawSuccess={handleWithdrawSuccess}
                  />
                )}

                {/* 4. Tab: Profil (Profile) */}
                {activeTab === 'profil' && (
                  <ProfileView
                    language={language}
                    onGoToEarnings={() => setActiveTab('pendapatan')}
                    onOpenHelp={() => setIsHelpModalOpen(true)}
                  />
                )}
              </>
            )}
          </>
        )}

        {/* VIEW 2: SUPPLIER PORTAL (HOTEL/FACTORY) */}
        {currentRole === 'supplier' && (
          <SupplierPortal
            language={language}
            listings={supplierListings}
            onAddListing={handleAddSupplierListing}
            onSwitchToCollector={() => {
              setCurrentRole('b40');
              setActiveTab('utama');
            }}
          />
        )}

        {/* VIEW 3: BUYER MARKETPLACE (ECOCRAFT/BUYER) */}
        {currentRole === 'buyer' && (
          <BuyerPortal
            language={language}
            products={buyerProducts}
            onSwitchToCollector={() => {
              setCurrentRole('b40');
              setActiveTab('utama');
            }}
          />
        )}

        {/* VIEW 4: PUBLIC LANDING PAGE */}
        {currentRole === 'landing' && (
          <LandingPageView
            language={language}
            onGoToCollector={(tab) => {
              setCurrentRole('b40');
              setActiveTab(tab || 'utama');
            }}
            onGoToSupplier={() => {
              setCurrentRole('supplier');
            }}
            onGoToBuyer={() => {
              setCurrentRole('buyer');
            }}
            onOpenHelpModal={() => {
              setIsHelpModalOpen(true);
            }}
          />
        )}
      </main>

      {/* Persistent Bottom Navigation for B40 Mobile & Responsive Flow (Only 4 items!) */}
      {currentRole === 'b40' && !isSortingActive && (
        <BottomNav
          activeTab={activeTab}
          setActiveTab={(tab) => setActiveTab(tab)}
          language={language}
        />
      )}

      {/* ========================================================================= */}
      {/* MODALS & OVERLAYS */}
      {/* ========================================================================= */}

      {/* 1. Opportunity Details Modal */}
      {selectedOpportunity && (
        <OpportunityDetailModal
          opportunity={selectedOpportunity}
          language={language}
          onClose={() => setSelectedOpportunity(null)}
          onAccept={handleAcceptOpportunity}
        />
      )}

      {/* 2. Accept Confirmation Modal */}
      {acceptedOpportunity && (
        <AcceptConfirmationModal
          opportunity={acceptedOpportunity}
          language={language}
          onCloseToHome={() => {
            setAcceptedOpportunity(null);
            setActiveTab('utama');
          }}
        />
      )}

      {/* 3. Listing Preview Modal */}
      {sortingDataForListing && (
        <ListingPreviewModal
          language={language}
          data={sortingDataForListing}
          onEdit={() => {
            setSortingDataForListing(null);
            setIsSortingActive(true);
          }}
          onConfirmListing={handleConfirmListing}
          onGoToEarnings={() => {
            setSortingDataForListing(null);
            setActiveTab('pendapatan');
          }}
        />
      )}

      {/* 4. Buyer Match Modal ("Ada Pembeli!") */}
      {isBuyerMatchOpen && (
        <BuyerMatchModal
          language={language}
          onClose={() => setIsBuyerMatchOpen(false)}
          onAcceptOrder={handleAcceptBuyerOrder}
        />
      )}

      {/* 5. Payment Success Modal ("Kain anda sudah terjual! 🎉") */}
      {isPaymentSuccessOpen && (
        <PaymentSuccessModal
          language={language}
          amount={18}
          onClose={() => setIsPaymentSuccessOpen(false)}
          onGoToEarnings={() => {
            setIsPaymentSuccessOpen(false);
            setActiveTab('pendapatan');
          }}
        />
      )}

      {/* 6. RM100 Goal Detail Modal */}
      {isGoalModalOpen && (
        <GoalDetailModal
          language={language}
          onClose={() => setIsGoalModalOpen(false)}
          onFindOpportunities={() => {
            setIsGoalModalOpen(false);
            setActiveTab('peluang');
          }}
        />
      )}

      {/* 7. Help Modal ("❓ Perlukan bantuan?") */}
      {isHelpModalOpen && (
        <HelpModal
          language={language}
          onClose={() => setIsHelpModalOpen(false)}
        />
      )}
    </div>
  );
}
